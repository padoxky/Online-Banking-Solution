-- phpMyAdmin SQL Dump
-- version 2.11.11.3
-- http://www.phpmyadmin.net
--
-- Host: 184.168.45.9
-- Generation Time: Aug 08, 2011 at 04:09 PM
-- Server version: 5.0.91
-- PHP Version: 5.1.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bankc35320110808`
--
CREATE DATABASE `bankc35320110808` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bankc35320110808`;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `account_number` mediumint(8) unsigned NOT NULL auto_increment,
  `balance` float default NULL,
  `option` mediumint(8) unsigned default NULL,
  `type` mediumint(8) unsigned default NULL,
  `client_id` mediumint(8) unsigned default NULL,
  PRIMARY KEY  (`account_number`),
  KEY `option` (`option`),
  KEY `type` (`type`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` VALUES(1, 78373, 1, 6, 47);
INSERT INTO `account` VALUES(2, 71937, 3, 1, 10);
INSERT INTO `account` VALUES(3, 25678, 1, 4, 1);
INSERT INTO `account` VALUES(4, 47726, 3, 2, 43);
INSERT INTO `account` VALUES(5, 88758, 1, 6, 20);
INSERT INTO `account` VALUES(6, 7.39733e+08, 1, 7, 5);
INSERT INTO `account` VALUES(7, 2.14748e+09, 1, 8, 15);
INSERT INTO `account` VALUES(8, 1.50276e+07, 1, 3, 4);
INSERT INTO `account` VALUES(9, 31936.2, 3, 10, 2);
INSERT INTO `account` VALUES(10, 1020, 1, 3, 40);
INSERT INTO `account` VALUES(11, 2.14748e+09, 2, 8, 36);
INSERT INTO `account` VALUES(12, 61983, 3, 6, 26);
INSERT INTO `account` VALUES(13, 17883, 1, 9, 46);
INSERT INTO `account` VALUES(14, 1.18882e+09, 2, 1, 13);
INSERT INTO `account` VALUES(15, 72504, 3, 6, 1);
INSERT INTO `account` VALUES(16, 7079, 3, 1, 20);
INSERT INTO `account` VALUES(17, 42832, 1, 5, 42);
INSERT INTO `account` VALUES(18, 13681, 3, 7, 19);
INSERT INTO `account` VALUES(19, 30360, 2, 1, 46);
INSERT INTO `account` VALUES(20, 2.14748e+09, 2, 5, 26);
INSERT INTO `account` VALUES(21, 75929, 1, 5, 44);
INSERT INTO `account` VALUES(22, 87361, 2, 2, 30);
INSERT INTO `account` VALUES(23, 19856, 2, 7, 14);
INSERT INTO `account` VALUES(24, 2.14748e+09, 3, 7, 39);
INSERT INTO `account` VALUES(25, 72892, 1, 7, 44);
INSERT INTO `account` VALUES(26, 76225, 1, 3, 4);
INSERT INTO `account` VALUES(27, 65028, 1, 10, 49);
INSERT INTO `account` VALUES(28, 97847, 2, 5, 37);
INSERT INTO `account` VALUES(29, 73030, 3, 7, 31);
INSERT INTO `account` VALUES(30, 35356.9, 3, 3, 28);
INSERT INTO `account` VALUES(31, 34047, 3, 9, 35);
INSERT INTO `account` VALUES(32, 47570, 2, 5, 11);
INSERT INTO `account` VALUES(33, 57283, 1, 1, 17);
INSERT INTO `account` VALUES(34, 31185, 1, 5, 49);
INSERT INTO `account` VALUES(35, 63585, 2, 10, 31);
INSERT INTO `account` VALUES(36, 79673, 2, 4, 27);
INSERT INTO `account` VALUES(37, 34407, 3, 2, 35);
INSERT INTO `account` VALUES(38, 68571, 2, 3, 2);
INSERT INTO `account` VALUES(39, 13843, 1, 8, 31);
INSERT INTO `account` VALUES(40, 54848, 1, 9, 7);
INSERT INTO `account` VALUES(41, 24871, 3, 5, 29);
INSERT INTO `account` VALUES(42, 19858, 3, 6, 42);
INSERT INTO `account` VALUES(43, 24406, 2, 7, 3);
INSERT INTO `account` VALUES(44, 89398, 3, 6, 13);
INSERT INTO `account` VALUES(45, 76882, 3, 10, 23);
INSERT INTO `account` VALUES(46, 3209, 1, 5, 9);
INSERT INTO `account` VALUES(47, 24915, 1, 8, 40);
INSERT INTO `account` VALUES(48, 36814, 2, 10, 31);
INSERT INTO `account` VALUES(49, 49253, 2, 2, 35);
INSERT INTO `account` VALUES(50, 23255, 3, 6, 24);
INSERT INTO `account` VALUES(51, 16453, 3, 6, 3);
INSERT INTO `account` VALUES(52, 77511, 1, 3, 28);
INSERT INTO `account` VALUES(53, 78404, 1, 10, 41);
INSERT INTO `account` VALUES(54, 41268, 2, 10, 34);
INSERT INTO `account` VALUES(55, 67283, 3, 5, 3);
INSERT INTO `account` VALUES(56, 37476, 2, 7, 44);
INSERT INTO `account` VALUES(57, 75375, 3, 6, 50);
INSERT INTO `account` VALUES(58, 53533, 1, 5, 35);
INSERT INTO `account` VALUES(59, 5824, 3, 8, 42);
INSERT INTO `account` VALUES(60, 6588, 1, 4, 43);
INSERT INTO `account` VALUES(61, 28595, 2, 7, 35);
INSERT INTO `account` VALUES(62, 85485, 2, 4, 27);
INSERT INTO `account` VALUES(63, 42403, 3, 6, 40);
INSERT INTO `account` VALUES(64, 19835, 1, 7, 48);
INSERT INTO `account` VALUES(65, 6171, 1, 10, 30);
INSERT INTO `account` VALUES(66, 30845, 2, 3, 19);
INSERT INTO `account` VALUES(67, 38220, 1, 3, 23);
INSERT INTO `account` VALUES(68, 11024, 2, 3, 20);
INSERT INTO `account` VALUES(69, 95301, 3, 1, 41);
INSERT INTO `account` VALUES(70, 61675, 2, 4, 3);
INSERT INTO `account` VALUES(81, 89.23, 2, 7, 6);
INSERT INTO `account` VALUES(83, 12094.6, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` mediumint(8) unsigned NOT NULL auto_increment,
  `branch_name` text,
  `address` varchar(255) default NULL,
  `city` varchar(50) default NULL,
  `phone` varchar(100) default NULL,
  `fax` varchar(100) default NULL,
  `opening_date` datetime default NULL,
  `manager_id` mediumint(8) unsigned default NULL,
  PRIMARY KEY  (`branch_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` VALUES(1, 'abissi', '449-6224 Lacus Av.', 'Jacksonville', '1-411-665-3237', '1-417-192-1252', '2009-03-31 23:33:34', 2);
INSERT INTO `branch` VALUES(2, 'massa', '852-3907 Sed Ave', 'Billings', '1-277-528-6752', '1-286-928-6278', '2009-10-12 21:22:17', 5);
INSERT INTO `branch` VALUES(3, 'bonto', '387 Integer Road', 'montreal', '1-529-831-6068', '1-936-557-3175', '2009-04-17 01:04:50', 8);
INSERT INTO `branch` VALUES(4, 'elementum', '1848 Ridiculus Av.', 'Hagerstown', '1-751-876-0744', '1-815-595-8604', '2009-04-17 19:23:47', 11);
INSERT INTO `branch` VALUES(5, '', '', '', '', '', '0000-00-00 00:00:00', 14);
INSERT INTO `branch` VALUES(6, 'sem', 'P.O. Box 661, 9579 Mauris Rd.', 'toronto', '1-793-287-8180', '1-579-575-9195', '2008-03-25 12:20:56', 17);
INSERT INTO `branch` VALUES(7, 'Suspendisse', 'Ap #753-3847 Fringilla, St.', 'ottawa', '1-901-771-0997', '1-706-753-6001', '2008-04-15 05:27:06', 20);
INSERT INTO `branch` VALUES(8, 'sollicitudin', 'Ap #432-1199 Vestibulum St.', 'ottawa', '1-181-271-3484', '1-584-355-9302', '2010-07-30 16:17:03', 23);
INSERT INTO `branch` VALUES(9, 'ipsum', 'P.O. Box 225, 5903 Dolor. Road', 'Guayanilla', '1-794-593-6107', '1-556-105-4309', '2011-03-10 15:54:33', 26);
INSERT INTO `branch` VALUES(10, 'ligula', 'Ap #445-1694 Sed St.', 'Yukon', '1-635-905-3556', '1-267-922-6231', '2002-12-14 05:55:01', 29);
INSERT INTO `branch` VALUES(11, 'SaintCatherine', '734 saintcatherine', 'montreal', '1-514-999-9999', '1-514-999-9991', '2009-03-31 23:33:34', 4);
INSERT INTO `branch` VALUES(13, 'LOL', 'LOL ADDRESS', 'LOL CITY', 'LOL PHONE', 'LOL FAX', '0000-00-00 00:00:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` mediumint(8) unsigned NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `dob` date default NULL,
  `joining_date` datetime default NULL,
  `password` varchar(64) NOT NULL default '''12345''',
  PRIMARY KEY  (`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` VALUES(1, 'Jillian Hoffman', '777-4931 Vel St.', '1985-01-14', '2009-04-04 02:24:32', '12345');
INSERT INTO `client` VALUES(2, 'Rebecca Howard', 'P.O. Box 923, 7040 Porttitor St.', '1966-03-30', '2007-10-25 01:06:57', '12345');
INSERT INTO `client` VALUES(3, 'Destiny York', 'P.O. Box 575, 1325 Erat. Road', '1982-11-10', '2004-02-25 20:25:28', '12345');
INSERT INTO `client` VALUES(4, 'Albert Pennington', 'P.O. Box 313, 7645 Id Ave', '2002-12-07', '2002-08-05 21:49:53', '12345');
INSERT INTO `client` VALUES(5, 'Rigel Conner', 'Ap #794-4253 Mi Street', '1998-03-21', '2002-11-19 10:19:14', '12345');
INSERT INTO `client` VALUES(6, 'Acton Lawrence', '3672 Nunc Av.', '1969-06-08', '2001-11-04 15:03:08', '12345');
INSERT INTO `client` VALUES(7, 'Wynter Cooper', '345-7697 Tempus Rd.', '2005-10-10', '2006-01-08 07:23:02', '12345');
INSERT INTO `client` VALUES(8, 'Richard Grimes', '111-8369 Amet Avenue', '1975-04-03', '2005-12-22 14:55:44', '12345');
INSERT INTO `client` VALUES(9, 'Brielle Doyle', 'P.O. Box 340, 3965 Neque. Av.', '1997-10-10', '2007-07-02 19:49:44', '12345');
INSERT INTO `client` VALUES(10, 'Garth Sykes', '6889 Nulla Ave', '1987-02-26', '2003-01-11 05:05:51', '12345');
INSERT INTO `client` VALUES(11, 'Merritt Owen', 'Ap #873-3139 Metus. St.', '1989-09-09', '2004-03-19 15:10:37', '12345');
INSERT INTO `client` VALUES(12, 'Flavia Galloway', 'P.O. Box 951, 3924 Id, St.', '1993-03-15', '2010-12-26 17:18:03', '12345');
INSERT INTO `client` VALUES(13, 'Angelica Francis', '685-9626 Augue Avenue', '1992-06-15', '2003-06-09 14:51:29', '12345');
INSERT INTO `client` VALUES(14, 'Finn Parsons', 'P.O. Box 208, 8737 Et Ave', '1952-05-26', '2008-08-01 14:46:29', '12345');
INSERT INTO `client` VALUES(15, 'Robert Anthony', 'Ap #294-5154 Malesuada. Rd.', '1975-09-04', '2003-12-12 03:07:12', '12345');
INSERT INTO `client` VALUES(16, 'Gwendolyn Blair', '457-7850 Eu Ave', '1986-03-03', '2004-01-04 14:23:10', '12345');
INSERT INTO `client` VALUES(17, 'Keaton Glass', 'Ap #611-4762 Libero Rd.', '1976-03-10', '2003-10-23 03:37:44', '12345');
INSERT INTO `client` VALUES(18, 'Autumn Dale', '6660 Varius Road', '2010-07-29', '2001-10-09 10:41:01', '12345');
INSERT INTO `client` VALUES(19, 'Bo Wilkerson', '8028 Sit Avenue', '2003-10-13', '2005-05-15 15:34:47', '12345');
INSERT INTO `client` VALUES(20, 'Kerry Dyer', '8846 Id, Ave', '1981-01-08', '2003-09-30 17:35:44', '12345');
INSERT INTO `client` VALUES(21, 'Sasha Mcdaniel', '3656 Elit, Street', '2008-07-31', '2009-11-22 15:51:38', '12345');
INSERT INTO `client` VALUES(22, 'Portia Gates', '1055 Gravida Road', '2004-05-15', '2006-07-22 23:39:50', '12345');
INSERT INTO `client` VALUES(23, 'Robin Benjamin', '314-9079 Eget, Street', '1972-01-13', '2010-10-03 04:21:34', '12345');
INSERT INTO `client` VALUES(24, 'Lani Crane', '4958 Nisl. Rd.', '1952-04-10', '2004-03-29 09:39:17', '12345');
INSERT INTO `client` VALUES(25, 'Berk Drake', 'P.O. Box 898, 6941 Curabitur Av.', '1980-04-29', '2004-10-24 02:30:47', '12345');
INSERT INTO `client` VALUES(26, 'Lynn Hutchinson', '6859 Ac Rd.', '1966-10-23', '2003-05-13 14:44:06', '12345');
INSERT INTO `client` VALUES(27, 'Venus Good', '850-9745 Massa Avenue', '2007-04-25', '2011-05-20 00:04:23', '12345');
INSERT INTO `client` VALUES(28, 'Priscilla Blankenship', '191 Enim St.', '1973-05-31', '2006-10-12 02:29:07', '12345');
INSERT INTO `client` VALUES(29, 'Coby Norris', 'P.O. Box 699, 4600 Arcu. St.', '1976-03-31', '2010-03-13 12:31:35', '12345');
INSERT INTO `client` VALUES(30, 'Cassandra Lawrence', 'P.O. Box 185, 5259 Sagittis St.', '1961-09-03', '2005-08-18 23:27:12', '12345');
INSERT INTO `client` VALUES(31, 'Buffy Pace', 'Ap #726-8451 Lacinia Av.', '1985-04-26', '2007-10-11 00:43:25', '12345');
INSERT INTO `client` VALUES(32, 'Kevin Carey', '7584 Penatibus Rd.', '2002-06-22', '2007-03-10 08:53:52', '12345');
INSERT INTO `client` VALUES(33, 'Whoopi Trevino', 'P.O. Box 475, 5343 Suspendisse Avenue', '1959-06-27', '2010-06-24 18:44:47', '12345');
INSERT INTO `client` VALUES(34, 'Ferdinand Mcclain', '7214 Sit Ave', '1960-11-16', '2010-01-30 04:40:33', '12345');
INSERT INTO `client` VALUES(35, 'Debra Sampson', '163-540 Mi Road', '1966-04-01', '2008-10-03 09:56:40', '12345');
INSERT INTO `client` VALUES(36, 'Mira Talley', 'Ap #296-5195 Lectus. Road', '1973-07-12', '2009-10-20 20:37:02', '12345');
INSERT INTO `client` VALUES(37, 'Howard Powell', 'Ap #394-9112 A, St.', '1999-04-16', '2003-02-27 08:18:06', '12345');
INSERT INTO `client` VALUES(38, 'Matthew Horne', '9107 Et St.', '1962-01-19', '2010-08-12 21:28:45', '12345');
INSERT INTO `client` VALUES(39, 'Hammett Little', '4781 Donec St.', '1995-08-22', '2008-06-12 23:04:04', '12345');
INSERT INTO `client` VALUES(40, 'Ali Campbell', 'P.O. Box 531, 9923 Erat St.', '1972-02-17', '2010-05-19 12:10:23', '12345');
INSERT INTO `client` VALUES(41, 'Sierra Skinner', '226-8134 Faucibus St.', '2006-11-07', '2005-03-12 13:31:44', '12345');
INSERT INTO `client` VALUES(42, 'Ray Franks', 'P.O. Box 239, 5631 Fusce St.', '1956-02-26', '2001-10-18 23:22:15', '12345');
INSERT INTO `client` VALUES(43, 'Kiayada Giles', 'Ap #873-1278 Nunc Rd.', '1973-11-13', '2003-02-21 15:06:49', '12345');
INSERT INTO `client` VALUES(44, 'Rooney Moses', '4022 Imperdiet Av.', '2005-11-05', '2004-02-18 00:05:34', '12345');
INSERT INTO `client` VALUES(45, 'Wade Wiley', '7297 Commodo Avenue', '1966-05-30', '2006-02-05 05:32:50', '12345');
INSERT INTO `client` VALUES(46, 'Melodie Torres', 'Ap #891-1226 Quisque Av.', '1953-07-13', '2005-07-17 23:46:25', '12345');
INSERT INTO `client` VALUES(47, 'Colorado Wynn', 'Ap #891-7126 Arcu Road', '1982-03-25', '2005-08-10 12:19:48', '12345');
INSERT INTO `client` VALUES(48, 'Steven Gibson', '316-3896 Lectus Ave', '2011-06-03', '2004-10-18 09:28:01', '12345');
INSERT INTO `client` VALUES(49, 'Amethyst Booker', 'P.O. Box 227, 3262 A, Road', '1990-06-22', '2008-08-13 09:40:57', '12345');
INSERT INTO `client` VALUES(50, 'Xander Wilcox', '1478 Pede. Rd.', '1954-11-09', '2008-01-25 20:42:02', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `clientele`
--

CREATE TABLE `clientele` (
  `client_id` mediumint(8) unsigned NOT NULL,
  `branch_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY  (`client_id`,`branch_id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clientele`
--

INSERT INTO `clientele` VALUES(12, 1);
INSERT INTO `clientele` VALUES(27, 1);
INSERT INTO `clientele` VALUES(32, 1);
INSERT INTO `clientele` VALUES(41, 1);
INSERT INTO `clientele` VALUES(49, 1);
INSERT INTO `clientele` VALUES(6, 2);
INSERT INTO `clientele` VALUES(8, 2);
INSERT INTO `clientele` VALUES(34, 2);
INSERT INTO `clientele` VALUES(40, 2);
INSERT INTO `clientele` VALUES(45, 2);
INSERT INTO `clientele` VALUES(48, 2);
INSERT INTO `clientele` VALUES(7, 3);
INSERT INTO `clientele` VALUES(18, 3);
INSERT INTO `clientele` VALUES(37, 3);
INSERT INTO `clientele` VALUES(43, 3);
INSERT INTO `clientele` VALUES(10, 4);
INSERT INTO `clientele` VALUES(14, 4);
INSERT INTO `clientele` VALUES(5, 5);
INSERT INTO `clientele` VALUES(23, 5);
INSERT INTO `clientele` VALUES(29, 5);
INSERT INTO `clientele` VALUES(33, 5);
INSERT INTO `clientele` VALUES(4, 6);
INSERT INTO `clientele` VALUES(21, 6);
INSERT INTO `clientele` VALUES(30, 6);
INSERT INTO `clientele` VALUES(35, 6);
INSERT INTO `clientele` VALUES(1, 7);
INSERT INTO `clientele` VALUES(3, 7);
INSERT INTO `clientele` VALUES(15, 7);
INSERT INTO `clientele` VALUES(28, 7);
INSERT INTO `clientele` VALUES(31, 7);
INSERT INTO `clientele` VALUES(13, 8);
INSERT INTO `clientele` VALUES(20, 8);
INSERT INTO `clientele` VALUES(26, 8);
INSERT INTO `clientele` VALUES(38, 8);
INSERT INTO `clientele` VALUES(44, 8);
INSERT INTO `clientele` VALUES(47, 8);
INSERT INTO `clientele` VALUES(50, 8);
INSERT INTO `clientele` VALUES(25, 9);
INSERT INTO `clientele` VALUES(46, 9);
INSERT INTO `clientele` VALUES(9, 10);
INSERT INTO `clientele` VALUES(11, 10);
INSERT INTO `clientele` VALUES(36, 10);
INSERT INTO `clientele` VALUES(42, 10);
INSERT INTO `clientele` VALUES(2, 11);
INSERT INTO `clientele` VALUES(16, 11);
INSERT INTO `clientele` VALUES(17, 11);
INSERT INTO `clientele` VALUES(19, 11);
INSERT INTO `clientele` VALUES(22, 11);
INSERT INTO `clientele` VALUES(24, 11);
INSERT INTO `clientele` VALUES(39, 11);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` mediumint(8) unsigned NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `address` varchar(255) default NULL,
  `salary` varchar(50) default NULL,
  `start_date` datetime default NULL,
  `branch_id` mediumint(8) unsigned default NULL,
  `password` varchar(64) NOT NULL default '''12345''',
  PRIMARY KEY  (`employee_id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` VALUES(1, '', '', '', '', '0000-00-00 00:00:00', 1, '12345');
INSERT INTO `employee` VALUES(2, 'Dr.', 'Deirdre Silva', '3437 Pellentesque Rd.', '6973', '2005-12-31 14:31:25', 1, '12345');
INSERT INTO `employee` VALUES(3, 'Mrs.', 'Wade Hahn', 'Ap #675-7055 Lacinia. Avenue', '5602', '2008-06-14 18:54:54', 10, '12345');
INSERT INTO `employee` VALUES(4, '', 'Orson Glenn', 'P.O. Box 176, 5217 Lacus. Street', '9883', '2011-08-07 13:44:28', 11, '12345');
INSERT INTO `employee` VALUES(5, 'Mrs.', 'Chiquita Key', 'Ap #647-2049 Lorem Av.', '3291', '2001-09-29 04:11:43', 2, '12345');
INSERT INTO `employee` VALUES(6, 'Mr.', 'Piper Reeves', 'Ap #184-1246 A Ave', '9286', '2012-02-01 19:32:53', 4, '12345');
INSERT INTO `employee` VALUES(7, '', 'Timothy Townsend', 'Ap #401-6520 Id, St.', '3348', '2007-05-24 15:43:06', 2, '12345');
INSERT INTO `employee` VALUES(8, 'Mrs.', 'Ivana Bender', '156-4909 Lectus Ave', '6711', '2012-01-08 11:49:52', 3, '12345');
INSERT INTO `employee` VALUES(9, '', 'Ayanna Craig', '858-8629 Mi Avenue', '6350', '2008-02-10 02:03:23', 11, '12345');
INSERT INTO `employee` VALUES(10, 'Dr.', 'Barclay Rowland', 'P.O. Box 132, 5082 Interdum Road', '5669', '2011-08-06 16:14:04', 9, '12345');
INSERT INTO `employee` VALUES(11, 'Mr.', 'Hunter Duke', 'P.O. Box 304, 5775 Nec, Road', '2039', '2012-02-24 06:02:23', 4, '12345');
INSERT INTO `employee` VALUES(12, 'Mrs.', 'Wendy Klein', 'P.O. Box 675, 3989 Turpis Rd.', '8318', '2001-08-27 03:04:16', 1, '12345');
INSERT INTO `employee` VALUES(13, 'Mrs.', 'Lydia Griffith', '1295 Est Av.', '2062', '2011-04-17 05:53:33', 11, '12345');
INSERT INTO `employee` VALUES(14, 'Ms.', 'Hyacinth Gentry', '736-3324 Non Road', '8966', '2007-09-25 12:12:26', 5, '12345');
INSERT INTO `employee` VALUES(15, 'Mr.', 'Uriah Witt', 'Ap #136-3903 Nunc Ave', '9402', '2006-08-20 07:56:32', 9, '12345');
INSERT INTO `employee` VALUES(16, '', 'Malik Goodwin', '173-1235 Ornare Av.', '5485', '2007-07-02 01:02:17', 6, '12345');
INSERT INTO `employee` VALUES(17, 'Mr.', 'Jaquelyn Palmer', 'P.O. Box 470, 3510 Donec Road', '9365', '2003-08-23 02:16:59', 6, '12345');
INSERT INTO `employee` VALUES(18, 'Dr.', 'Norman Sandoval', 'P.O. Box 272, 9379 Malesuada. Rd.', '8592', '2006-08-20 06:35:34', 11, '12345');
INSERT INTO `employee` VALUES(19, 'Mrs.', 'Hannah Mcclain', '5230 Aliquam St.', '8772', '2007-09-28 17:43:08', 5, '12345');
INSERT INTO `employee` VALUES(20, 'Mr.', 'Riley Barton', 'Ap #985-4979 Donec Ave', '4857', '2006-08-22 20:57:53', 7, '12345');
INSERT INTO `employee` VALUES(21, 'Mr.', 'Ivy Patrick', '2197 Sed Road', '7812', '2008-04-17 04:42:30', 5, '12345');
INSERT INTO `employee` VALUES(22, 'Dr.', 'Raphael Rosales', 'Ap #901-4698 Fringilla Rd.', '7334', '2004-07-10 02:52:56', 1, '12345');
INSERT INTO `employee` VALUES(23, 'Mrs.', 'Paula Madden', '842-8062 Fringilla Road', '9988', '2005-09-28 15:52:39', 8, '12345');
INSERT INTO `employee` VALUES(24, '', 'Cathleen Nichols', '675-3156 Scelerisque Rd.', '2032', '2001-08-15 19:38:38', 4, '12345');
INSERT INTO `employee` VALUES(25, 'Ms.', 'Allegra Adams', 'Ap #761-6071 Sit St.', '5924', '2008-05-21 01:36:25', 1, '12345');
INSERT INTO `employee` VALUES(26, 'Dr.', 'Kylan Black', 'P.O. Box 874, 6304 Commodo Avenue', '8795', '2001-07-23 22:48:10', 9, '12345');
INSERT INTO `employee` VALUES(27, 'Mr.', 'Riley Mosley', '307-5763 Lorem Rd.', '3770', '2005-08-04 14:40:39', 4, '12345');
INSERT INTO `employee` VALUES(28, 'Ms.', 'Brody Rivers', 'Ap #809-1055 Faucibus St.', '4191', '2004-12-24 21:11:34', 9, '12345');
INSERT INTO `employee` VALUES(29, 'Ms.', 'Leslie Hubbard', 'Ap #354-9289 Amet Street', '8558', '2001-12-20 09:21:24', 10, '12345');
INSERT INTO `employee` VALUES(30, 'Ms.', 'George Pope', 'Ap #756-154 Ac Street', '8348', '2001-10-18 08:33:06', 9, '12345');
INSERT INTO `employee` VALUES(31, 'Mr.', 'Gil Weiss', '8370 Nec, Ave', '2628', '2002-06-26 08:38:08', 5, '12345');
INSERT INTO `employee` VALUES(32, 'Mr.', 'Melodie Logan', '8471 Ornare, Ave', '1750', '2003-12-25 10:38:06', 8, '12345');
INSERT INTO `employee` VALUES(33, 'Ms.', 'Ferris Briggs', 'Ap #799-295 Dictum Avenue', '1533', '2011-02-17 14:35:19', 9, '12345');
INSERT INTO `employee` VALUES(34, 'Mrs.', 'Xavier Bernard', '2599 Mauris Av.', '5113', '2011-01-14 16:38:14', 4, '12345');
INSERT INTO `employee` VALUES(35, 'Mr.', 'Dorothy Welch', 'P.O. Box 105, 9089 Eu Rd.', '4087', '2008-07-11 03:44:17', 11, '12345');
INSERT INTO `employee` VALUES(36, 'Ms.', 'Blake Horn', 'P.O. Box 353, 8665 Nec, Avenue', '2549', '2005-03-10 07:17:54', 6, '12345');
INSERT INTO `employee` VALUES(37, 'Mr.', 'Cullen Finley', 'Ap #623-4495 Pede, Rd.', '5561', '2007-08-25 13:25:45', 2, '12345');
INSERT INTO `employee` VALUES(38, 'Mr.', 'Isaiah Winters', '1939 Integer St.', '6387', '2007-02-21 17:27:20', 1, '12345');
INSERT INTO `employee` VALUES(39, '', 'Stewart Snow', 'Ap #748-396 Justo Av.', '9000', '2005-06-08 06:19:42', 1, '12345');
INSERT INTO `employee` VALUES(40, 'Dr.', 'Asher Robertson', '6788 Dis Rd.', '1254', '2005-05-03 08:57:17', 10, '12345');
INSERT INTO `employee` VALUES(41, '', 'Rana Savage', 'P.O. Box 971, 3666 Erat. Rd.', '1363', '2009-05-18 18:13:56', 7, '12345');
INSERT INTO `employee` VALUES(42, 'Mr.', 'Keiko Galloway', '6752 Quis St.', '2484', '2006-11-13 21:25:18', 8, '12345');
INSERT INTO `employee` VALUES(43, 'Dr.', 'Rafael Herman', 'P.O. Box 718, 7444 Sed Avenue', '9743', '2003-04-16 11:49:24', 8, '12345');
INSERT INTO `employee` VALUES(44, 'Ms.', 'Chloe Downs', 'Ap #951-3749 Dui, Av.', '8815', '2007-09-18 08:35:46', 8, '12345');
INSERT INTO `employee` VALUES(45, '', 'Karleigh Morse', 'Ap #236-5073 Ligula. St.', '4505', '2006-07-26 21:45:38', 2, '12345');
INSERT INTO `employee` VALUES(46, '', 'Raphael Bolton', 'Ap #978-7131 A, Rd.', '4777', '2009-04-29 05:27:02', 9, '12345');
INSERT INTO `employee` VALUES(47, 'Ms.', 'Alden Morrison', '496-9987 Lectus Road', '6845', '2003-01-29 17:22:05', 6, '12345');
INSERT INTO `employee` VALUES(48, 'Mr.', 'Trevor Oneal', '900-8491 Non, Ave', '1821', '2005-10-02 21:59:30', 4, '12345');
INSERT INTO `employee` VALUES(49, '', 'Sybill Fry', '390-7118 Sit St.', '4284', '2007-03-06 10:09:04', 8, '12345');
INSERT INTO `employee` VALUES(50, 'Dr.', 'Gail French', '411-654 Varius Road', '5046', '2009-06-03 05:02:16', 2, '12345');
INSERT INTO `employee` VALUES(51, 'Ms.', 'Naomi Jimenez', '466-751 Quisque Ave', '7418', '2005-02-09 01:28:01', 6, '12345');
INSERT INTO `employee` VALUES(52, '', 'Noble Chan', '228 Sociis Road', '7275', '2009-03-12 10:18:20', 3, '12345');
INSERT INTO `employee` VALUES(53, 'Mrs.', 'Jolie Oneal', 'Ap #337-5244 Ultricies Av.', '2126', '2007-12-28 08:15:24', 9, '12345');
INSERT INTO `employee` VALUES(54, '', 'Dean Nichols', '7140 Augue, Street', '9976', '2001-11-13 00:49:02', 1, '12345');
INSERT INTO `employee` VALUES(55, 'Ms.', 'Aurelia Ayers', 'Ap #299-6130 Sit St.', '3589', '2006-03-26 10:01:25', 1, '12345');
INSERT INTO `employee` VALUES(56, '', 'Aquila Bond', '607-8506 Orci Rd.', '9504', '2012-07-06 16:31:57', 5, '12345');
INSERT INTO `employee` VALUES(57, 'Mr.', 'Rhea Kirk', '5960 Blandit Rd.', '6632', '2008-02-20 14:07:36', 8, '12345');
INSERT INTO `employee` VALUES(58, 'Mr.', 'Karen Wallace', 'P.O. Box 745, 5161 Diam. Rd.', '3781', '2010-03-19 18:14:13', 11, '12345');
INSERT INTO `employee` VALUES(59, '', 'Keith Valencia', 'P.O. Box 305, 1293 Arcu. Street', '5799', '2010-02-02 01:33:58', 9, '12345');
INSERT INTO `employee` VALUES(60, 'Mrs.', 'Brett Barry', '176-9679 Hendrerit. St.', '2108', '2009-12-08 20:24:54', 6, '12345');
INSERT INTO `employee` VALUES(61, 'Mrs.', 'Raya Castaneda', 'P.O. Box 661, 2186 Donec Street', '2895', '2007-11-15 08:25:32', 11, '12345');
INSERT INTO `employee` VALUES(62, 'Mrs.', 'Chandler Rodriguez', 'P.O. Box 400, 5630 Mauris Rd.', '7318', '2009-05-16 09:44:07', 5, '12345');
INSERT INTO `employee` VALUES(63, 'Mrs.', 'Flavia Lee', 'P.O. Box 706, 5317 Lectus Road', '2116', '2006-10-10 10:34:51', 11, '12345');
INSERT INTO `employee` VALUES(64, '', 'Nathaniel Higgins', 'P.O. Box 525, 5508 Ullamcorper, Ave', '4656', '2011-03-08 02:35:11', 11, '12345');
INSERT INTO `employee` VALUES(65, '', 'Blaine Jacobs', 'Ap #540-9684 Enim Road', '4610', '2006-12-05 10:13:49', 10, '12345');
INSERT INTO `employee` VALUES(66, 'Mrs.', 'Amelia Baird', '5704 Aliquam Street', '6824', '2005-09-05 22:15:04', 2, '12345');
INSERT INTO `employee` VALUES(67, 'Dr.', 'Dawn Montgomery', 'P.O. Box 935, 1042 Proin Avenue', '6825', '2009-09-16 17:07:33', 2, '12345');
INSERT INTO `employee` VALUES(68, 'Ms.', 'Kylie Horne', '6322 Vehicula Rd.', '7140', '2005-07-03 13:48:23', 10, '12345');
INSERT INTO `employee` VALUES(69, 'Mr.', 'Kirsten Vance', 'Ap #339-6497 Eu Road', '2791', '2001-07-19 14:44:16', 9, '12345');
INSERT INTO `employee` VALUES(70, 'Dr.', 'Alexa Shepherd', '791-7519 Nostra, St.', '8815', '2005-12-24 02:49:37', 3, '12345');
INSERT INTO `employee` VALUES(71, '', 'Kyla Haynes', '578-2283 Nec, Street', '8758', '2006-08-10 19:29:58', 11, '12345');
INSERT INTO `employee` VALUES(72, '', 'Walker Crawford', '3941 Diam. Ave', '5763', '2012-02-07 09:18:44', 3, '12345');
INSERT INTO `employee` VALUES(73, 'Mr.', 'Ryan Donovan', 'P.O. Box 802, 894 Quis Rd.', '5931', '2006-06-25 09:35:28', 9, '12345');
INSERT INTO `employee` VALUES(74, 'Mrs.', 'Summer Curtis', '3803 Nisl. St.', '9560', '2007-12-10 03:14:44', 1, '12345');
INSERT INTO `employee` VALUES(75, 'Mr.', 'Cassady Carroll', 'P.O. Box 121, 9452 Aliquet St.', '4332', '2005-07-13 09:22:00', 9, '12345');
INSERT INTO `employee` VALUES(76, 'Dr.', 'Ariel Espinoza', 'Ap #578-9592 Mattis St.', '7995', '2005-11-08 09:13:05', 11, '12345');
INSERT INTO `employee` VALUES(77, 'Ms.', 'Lane Ball', 'P.O. Box 753, 6685 Augue Rd.', '8716', '2003-04-27 09:09:36', 10, '12345');
INSERT INTO `employee` VALUES(78, 'Mr.', 'MacKensie Duran', '7435 Sociis St.', '4630', '2007-12-17 06:54:59', 9, '12345');
INSERT INTO `employee` VALUES(79, 'Mrs.', 'Pamela Coleman', '695-8833 Sed Street', '5643', '2009-03-07 02:46:26', 3, '12345');
INSERT INTO `employee` VALUES(80, '', 'Keely Rosario', 'Ap #110-378 Turpis Road', '8642', '2004-09-30 00:07:42', 8, '12345');
INSERT INTO `employee` VALUES(81, '', 'Hayes Downs', 'P.O. Box 340, 8450 Fringilla Rd.', '7994', '2003-06-04 01:52:25', 7, '12345');
INSERT INTO `employee` VALUES(82, 'Dr.', 'Mechelle Snyder', '560 Cum Rd.', '4584', '2011-03-07 16:58:17', 9, '12345');
INSERT INTO `employee` VALUES(83, 'Mr.', 'Scarlett Jefferson', '2169 Magnis Rd.', '8923', '2008-01-30 01:48:12', 2, '12345');
INSERT INTO `employee` VALUES(84, 'Mr.', 'Hanae Wheeler', '134-5536 Hendrerit Ave', '1517', '2009-03-22 02:55:03', 10, '12345');
INSERT INTO `employee` VALUES(85, 'Mr.', 'Aphrodite Mccullough', '150-8840 Enim St.', '8607', '2001-09-15 01:18:15', 8, '12345');
INSERT INTO `employee` VALUES(86, '', 'Tatiana Morrow', 'Ap #252-524 Tellus St.', '3059', '2010-12-07 03:33:02', 10, '12345');
INSERT INTO `employee` VALUES(87, '', 'Carly Keller', 'Ap #297-5727 Praesent Avenue', '2549', '2005-11-02 02:15:51', 3, '12345');
INSERT INTO `employee` VALUES(88, 'Mrs.', 'Veda Larson', '4375 Mauris Av.', '5403', '2010-05-15 23:34:42', 7, '12345');
INSERT INTO `employee` VALUES(89, 'Ms.', 'Griffith Mejia', 'P.O. Box 549, 8005 Nec Rd.', '5764', '2006-06-12 17:24:30', 8, '12345');
INSERT INTO `employee` VALUES(90, 'Mr.', 'Erica Carney', '167-4683 Nibh. Rd.', '8359', '2006-05-04 18:26:57', 7, '12345');
INSERT INTO `employee` VALUES(91, 'Ms.', 'Carlos Macias', 'P.O. Box 370, 5184 Felis, Avenue', '1992', '2006-07-25 05:31:07', 11, '12345');
INSERT INTO `employee` VALUES(92, 'Mr.', 'Dominique Kramer', '5217 Facilisi. St.', '3659', '2004-01-16 19:48:56', 2, '12345');
INSERT INTO `employee` VALUES(93, 'Ms.', 'Hollee Sears', '6158 Eu St.', '2487', '2011-02-27 16:20:53', 5, '12345');
INSERT INTO `employee` VALUES(94, 'Ms.', 'Laurel Morin', '562-2209 Magna. St.', '5705', '2006-12-31 11:12:52', 1, '12345');
INSERT INTO `employee` VALUES(95, 'Dr.', 'Xanthus Ball', '553-9662 Velit Rd.', '1742', '2003-01-04 18:54:08', 4, '12345');
INSERT INTO `employee` VALUES(96, 'Mr.', 'Halee Johnson', '800-5536 Vel Avenue', '1939', '2002-07-20 03:29:43', 11, '12345');
INSERT INTO `employee` VALUES(97, 'Mr.', 'Marshall Luna', '968-5670 Accumsan Rd.', '5358', '2005-10-26 17:53:38', 6, '12345');
INSERT INTO `employee` VALUES(98, 'Dr.', 'Evelyn Hull', 'Ap #300-7246 Et Street', '8116', '2011-08-30 07:31:55', 2, '12345');
INSERT INTO `employee` VALUES(99, 'Mr.', 'Jerome Johnston', '4199 Aliquet. Rd.', '2340', '2004-12-02 06:58:24', 9, '12345');
INSERT INTO `employee` VALUES(100, 'Dr.', 'Brianna Fisher', '2298 Sed St.', '4812', '2004-11-02 12:43:22', 3, '12345');

-- --------------------------------------------------------

--
-- Table structure for table `need`
--

CREATE TABLE `need` (
  `need` varchar(50) NOT NULL,
  PRIMARY KEY  (`need`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `need`
--

INSERT INTO `need` VALUES('business');
INSERT INTO `need` VALUES('corporate');
INSERT INTO `need` VALUES('personal');

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

CREATE TABLE `plan` (
  `option_id` mediumint(8) unsigned NOT NULL auto_increment,
  `option` varchar(50) NOT NULL,
  `transaction_limit` mediumint(9) NOT NULL,
  `credit_limit` mediumint(9) NOT NULL,
  `charge` mediumint(9) NOT NULL,
  PRIMARY KEY  (`option_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` VALUES(1, 'bronze', 10, 10000, 3);
INSERT INTO `plan` VALUES(2, 'silver', 100, 25000, 1);
INSERT INTO `plan` VALUES(3, 'gold', 1000, 40000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `rate`
--

CREATE TABLE `rate` (
  `type_id` mediumint(8) unsigned NOT NULL auto_increment,
  `type` varchar(50) NOT NULL,
  `percentage` tinyint(4) NOT NULL,
  `service` varchar(50) NOT NULL,
  `need` varchar(50) NOT NULL,
  PRIMARY KEY  (`type_id`),
  KEY `need` (`need`),
  KEY `service` (`service`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `rate`
--

INSERT INTO `rate` VALUES(1, 'business banking (CHECKING)', 0, 'banking', 'business');
INSERT INTO `rate` VALUES(2, 'business insurance', 2, 'insurance', 'business');
INSERT INTO `rate` VALUES(3, 'business investment', 2, 'investment', 'business');
INSERT INTO `rate` VALUES(4, 'corporate banking (LINE OF CREDIT)', 3, 'banking', 'corporate');
INSERT INTO `rate` VALUES(5, 'corporate insurance', 1, 'insurance', 'corporate');
INSERT INTO `rate` VALUES(6, 'corporate investment', 3, 'investment', 'corporate');
INSERT INTO `rate` VALUES(7, 'personal banking (CHECKING)', 0, 'banking', 'personal');
INSERT INTO `rate` VALUES(8, 'personal banking (SAVING)', 2, 'banking', 'personal');
INSERT INTO `rate` VALUES(9, 'personal insurance', 3, 'insurance', 'personal');
INSERT INTO `rate` VALUES(10, 'personal investment', 1, 'investment', 'personal');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service` varchar(50) NOT NULL,
  PRIMARY KEY  (`service`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service`
--

INSERT INTO `service` VALUES('banking');
INSERT INTO `service` VALUES('insurance');
INSERT INTO `service` VALUES('investment');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `transaction_id` mediumint(8) unsigned NOT NULL auto_increment,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `amount` decimal(10,0) NOT NULL,
  `type` varchar(50) NOT NULL,
  `account_number` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY  (`transaction_id`),
  KEY `type` (`type`),
  KEY `account_number` (`account_number`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` VALUES(3, '2011-08-04 19:20:09', 20, 'credit', 2);
INSERT INTO `transaction` VALUES(4, '2011-08-04 19:21:55', 34, 'debit', 5);
INSERT INTO `transaction` VALUES(5, '2011-08-04 19:21:55', 34, 'credit', 10);
INSERT INTO `transaction` VALUES(6, '2011-08-04 19:22:18', 10, 'debit', 1);
INSERT INTO `transaction` VALUES(7, '2011-08-04 20:07:44', 348, 'debit', 8);
INSERT INTO `transaction` VALUES(8, '2011-08-04 20:07:44', 348, 'credit', 12);
INSERT INTO `transaction` VALUES(9, '2011-08-04 20:09:46', 10, 'debit', 1);
INSERT INTO `transaction` VALUES(10, '2011-08-04 20:11:08', 3, 'credit', 10);
INSERT INTO `transaction` VALUES(11, '2011-08-04 20:22:08', 10, 'debit', 1);
INSERT INTO `transaction` VALUES(12, '2011-08-04 20:22:20', 20, 'credit', 6);
INSERT INTO `transaction` VALUES(13, '2011-08-04 20:22:29', 40, 'debit', 1);
INSERT INTO `transaction` VALUES(14, '2011-08-04 20:22:29', 40, 'credit', 1);
INSERT INTO `transaction` VALUES(15, '2011-08-04 20:32:13', 3, 'debit', 3);
INSERT INTO `transaction` VALUES(16, '2011-08-04 20:32:14', 3, 'credit', 1);
INSERT INTO `transaction` VALUES(17, '2011-08-05 10:19:43', 40000, 'debit', 10);
INSERT INTO `transaction` VALUES(18, '2011-08-05 22:59:14', 34, 'debit', 15);
INSERT INTO `transaction` VALUES(19, '2011-08-05 23:02:50', 4, 'debit', 15);
INSERT INTO `transaction` VALUES(20, '2011-08-05 23:04:55', 40, 'credit', 15);
INSERT INTO `transaction` VALUES(21, '2011-08-07 15:17:42', 12000, 'debit', 3);
INSERT INTO `transaction` VALUES(22, '2011-08-07 15:17:42', 12000, 'credit', 83);
INSERT INTO `transaction` VALUES(23, '2011-08-07 18:12:11', 15000000, 'credit', 8);
INSERT INTO `transaction` VALUES(24, '2011-08-08 13:48:28', 10, 'debit', 50);
INSERT INTO `transaction` VALUES(25, '2011-08-08 15:45:41', 10, 'credit', 15);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `type` varchar(50) NOT NULL,
  PRIMARY KEY  (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` VALUES('credit');
INSERT INTO `type` VALUES('debit');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `account_ibfk_1` FOREIGN KEY (`option`) REFERENCES `plan` (`option_id`),
  ADD CONSTRAINT `account_ibfk_2` FOREIGN KEY (`type`) REFERENCES `rate` (`type_id`),
  ADD CONSTRAINT `account_ibfk_3` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`);

--
-- Constraints for table `branch`
--
ALTER TABLE `branch`
  ADD CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`manager_id`) REFERENCES `employee` (`employee_id`);

--
-- Constraints for table `clientele`
--
ALTER TABLE `clientele`
  ADD CONSTRAINT `clientele_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`),
  ADD CONSTRAINT `clientele_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`);

--
-- Constraints for table `rate`
--
ALTER TABLE `rate`
  ADD CONSTRAINT `rate_ibfk_1` FOREIGN KEY (`need`) REFERENCES `need` (`need`),
  ADD CONSTRAINT `rate_ibfk_2` FOREIGN KEY (`service`) REFERENCES `service` (`service`);

--
-- Constraints for table `transaction`
--
ALTER TABLE `transaction`
  ADD CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`type`) REFERENCES `type` (`type`),
  ADD CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`account_number`) REFERENCES `account` (`account_number`);
--
-- Database: `information_schema`
--
CREATE DATABASE `information_schema` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `information_schema`;

-- --------------------------------------------------------

--
-- Table structure for table `CHARACTER_SETS`
--

CREATE TEMPORARY TABLE `CHARACTER_SETS` (
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_COLLATE_NAME` varchar(64) NOT NULL default '',
  `DESCRIPTION` varchar(60) NOT NULL default '',
  `MAXLEN` bigint(3) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CHARACTER_SETS`
--

INSERT INTO `CHARACTER_SETS` VALUES('big5', 'big5_chinese_ci', 'Big5 Traditional Chinese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('dec8', 'dec8_swedish_ci', 'DEC West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp850', 'cp850_general_ci', 'DOS West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('hp8', 'hp8_english_ci', 'HP West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('koi8r', 'koi8r_general_ci', 'KOI8-R Relcom Russian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('latin1', 'latin1_swedish_ci', 'cp1252 West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('latin2', 'latin2_general_ci', 'ISO 8859-2 Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('swe7', 'swe7_swedish_ci', '7bit Swedish', 1);
INSERT INTO `CHARACTER_SETS` VALUES('ascii', 'ascii_general_ci', 'US ASCII', 1);
INSERT INTO `CHARACTER_SETS` VALUES('ujis', 'ujis_japanese_ci', 'EUC-JP Japanese', 3);
INSERT INTO `CHARACTER_SETS` VALUES('sjis', 'sjis_japanese_ci', 'Shift-JIS Japanese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('hebrew', 'hebrew_general_ci', 'ISO 8859-8 Hebrew', 1);
INSERT INTO `CHARACTER_SETS` VALUES('tis620', 'tis620_thai_ci', 'TIS620 Thai', 1);
INSERT INTO `CHARACTER_SETS` VALUES('euckr', 'euckr_korean_ci', 'EUC-KR Korean', 2);
INSERT INTO `CHARACTER_SETS` VALUES('koi8u', 'koi8u_general_ci', 'KOI8-U Ukrainian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('gb2312', 'gb2312_chinese_ci', 'GB2312 Simplified Chinese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('greek', 'greek_general_ci', 'ISO 8859-7 Greek', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1250', 'cp1250_general_ci', 'Windows Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('gbk', 'gbk_chinese_ci', 'GBK Simplified Chinese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('latin5', 'latin5_turkish_ci', 'ISO 8859-9 Turkish', 1);
INSERT INTO `CHARACTER_SETS` VALUES('armscii8', 'armscii8_general_ci', 'ARMSCII-8 Armenian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('utf8', 'utf8_general_ci', 'UTF-8 Unicode', 3);
INSERT INTO `CHARACTER_SETS` VALUES('ucs2', 'ucs2_general_ci', 'UCS-2 Unicode', 2);
INSERT INTO `CHARACTER_SETS` VALUES('cp866', 'cp866_general_ci', 'DOS Russian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('keybcs2', 'keybcs2_general_ci', 'DOS Kamenicky Czech-Slovak', 1);
INSERT INTO `CHARACTER_SETS` VALUES('macce', 'macce_general_ci', 'Mac Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('macroman', 'macroman_general_ci', 'Mac West European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp852', 'cp852_general_ci', 'DOS Central European', 1);
INSERT INTO `CHARACTER_SETS` VALUES('latin7', 'latin7_general_ci', 'ISO 8859-13 Baltic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1251', 'cp1251_general_ci', 'Windows Cyrillic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1256', 'cp1256_general_ci', 'Windows Arabic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp1257', 'cp1257_general_ci', 'Windows Baltic', 1);
INSERT INTO `CHARACTER_SETS` VALUES('binary', 'binary', 'Binary pseudo charset', 1);
INSERT INTO `CHARACTER_SETS` VALUES('geostd8', 'geostd8_general_ci', 'GEOSTD8 Georgian', 1);
INSERT INTO `CHARACTER_SETS` VALUES('cp932', 'cp932_japanese_ci', 'SJIS for Windows Japanese', 2);
INSERT INTO `CHARACTER_SETS` VALUES('eucjpms', 'eucjpms_japanese_ci', 'UJIS for Windows Japanese', 3);

-- --------------------------------------------------------

--
-- Table structure for table `CLIENT_STATISTICS`
--

CREATE TEMPORARY TABLE `CLIENT_STATISTICS` (
  `CLIENT` varchar(64) NOT NULL default '',
  `TOTAL_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONCURRENT_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONNECTED_TIME` bigint(21) NOT NULL default '0',
  `BUSY_TIME` bigint(21) NOT NULL default '0',
  `CPU_TIME` bigint(21) NOT NULL default '0',
  `BYTES_RECEIVED` bigint(21) NOT NULL default '0',
  `BYTES_SENT` bigint(21) NOT NULL default '0',
  `BINLOG_BYTES_WRITTEN` bigint(21) NOT NULL default '0',
  `ROWS_FETCHED` bigint(21) NOT NULL default '0',
  `ROWS_UPDATED` bigint(21) NOT NULL default '0',
  `TABLE_ROWS_READ` bigint(21) NOT NULL default '0',
  `SELECT_COMMANDS` bigint(21) NOT NULL default '0',
  `UPDATE_COMMANDS` bigint(21) NOT NULL default '0',
  `OTHER_COMMANDS` bigint(21) NOT NULL default '0',
  `COMMIT_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `ROLLBACK_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `DENIED_CONNECTIONS` bigint(21) NOT NULL default '0',
  `LOST_CONNECTIONS` bigint(21) NOT NULL default '0',
  `ACCESS_DENIED` bigint(21) NOT NULL default '0',
  `EMPTY_QUERIES` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CLIENT_STATISTICS`
--

-- in use (#1227 - Access denied; you need the PROCESS,SUPER privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `COLLATIONS`
--

CREATE TEMPORARY TABLE `COLLATIONS` (
  `COLLATION_NAME` varchar(64) NOT NULL default '',
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `ID` bigint(11) NOT NULL default '0',
  `IS_DEFAULT` varchar(3) NOT NULL default '',
  `IS_COMPILED` varchar(3) NOT NULL default '',
  `SORTLEN` bigint(3) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLLATIONS`
--

INSERT INTO `COLLATIONS` VALUES('big5_chinese_ci', 'big5', 1, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('big5_bin', 'big5', 84, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('dec8_swedish_ci', 'dec8', 3, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('dec8_bin', 'dec8', 69, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp850_general_ci', 'cp850', 4, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp850_bin', 'cp850', 80, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('hp8_english_ci', 'hp8', 6, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('hp8_bin', 'hp8', 72, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('koi8r_general_ci', 'koi8r', 7, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('koi8r_bin', 'koi8r', 74, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('latin1_german1_ci', 'latin1', 5, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_swedish_ci', 'latin1', 8, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_danish_ci', 'latin1', 15, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_german2_ci', 'latin1', 31, '', 'Yes', 2);
INSERT INTO `COLLATIONS` VALUES('latin1_bin', 'latin1', 47, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_general_ci', 'latin1', 48, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_general_cs', 'latin1', 49, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin1_spanish_ci', 'latin1', 94, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_czech_cs', 'latin2', 2, '', 'Yes', 4);
INSERT INTO `COLLATIONS` VALUES('latin2_general_ci', 'latin2', 9, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_hungarian_ci', 'latin2', 21, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_croatian_ci', 'latin2', 27, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin2_bin', 'latin2', 77, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('swe7_swedish_ci', 'swe7', 10, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('swe7_bin', 'swe7', 82, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('ascii_general_ci', 'ascii', 11, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('ascii_bin', 'ascii', 65, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('ujis_japanese_ci', 'ujis', 12, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ujis_bin', 'ujis', 91, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('sjis_japanese_ci', 'sjis', 13, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('sjis_bin', 'sjis', 88, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('hebrew_general_ci', 'hebrew', 16, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('hebrew_bin', 'hebrew', 71, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('tis620_thai_ci', 'tis620', 18, 'Yes', 'Yes', 4);
INSERT INTO `COLLATIONS` VALUES('tis620_bin', 'tis620', 89, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('euckr_korean_ci', 'euckr', 19, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('euckr_bin', 'euckr', 85, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('koi8u_general_ci', 'koi8u', 22, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('koi8u_bin', 'koi8u', 75, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('gb2312_chinese_ci', 'gb2312', 24, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gb2312_bin', 'gb2312', 86, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('greek_general_ci', 'greek', 25, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('greek_bin', 'greek', 70, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1250_general_ci', 'cp1250', 26, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1250_czech_cs', 'cp1250', 34, '', 'Yes', 2);
INSERT INTO `COLLATIONS` VALUES('cp1250_croatian_ci', 'cp1250', 44, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp1250_bin', 'cp1250', 66, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gbk_chinese_ci', 'gbk', 28, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('gbk_bin', 'gbk', 87, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('latin5_turkish_ci', 'latin5', 30, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('latin5_bin', 'latin5', 78, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('armscii8_general_ci', 'armscii8', 32, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('armscii8_bin', 'armscii8', 64, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('utf8_general_ci', 'utf8', 33, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('utf8_bin', 'utf8', 83, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('utf8_unicode_ci', 'utf8', 192, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_icelandic_ci', 'utf8', 193, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_latvian_ci', 'utf8', 194, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_romanian_ci', 'utf8', 195, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_slovenian_ci', 'utf8', 196, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_polish_ci', 'utf8', 197, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_estonian_ci', 'utf8', 198, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_spanish_ci', 'utf8', 199, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_swedish_ci', 'utf8', 200, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_turkish_ci', 'utf8', 201, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_czech_ci', 'utf8', 202, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_danish_ci', 'utf8', 203, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_lithuanian_ci', 'utf8', 204, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_slovak_ci', 'utf8', 205, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_spanish2_ci', 'utf8', 206, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_roman_ci', 'utf8', 207, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_persian_ci', 'utf8', 208, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_esperanto_ci', 'utf8', 209, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('utf8_hungarian_ci', 'utf8', 210, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_general_ci', 'ucs2', 35, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ucs2_bin', 'ucs2', 90, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('ucs2_unicode_ci', 'ucs2', 128, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_icelandic_ci', 'ucs2', 129, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_latvian_ci', 'ucs2', 130, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_romanian_ci', 'ucs2', 131, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_slovenian_ci', 'ucs2', 132, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_polish_ci', 'ucs2', 133, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_estonian_ci', 'ucs2', 134, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_spanish_ci', 'ucs2', 135, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_swedish_ci', 'ucs2', 136, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_turkish_ci', 'ucs2', 137, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_czech_ci', 'ucs2', 138, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_danish_ci', 'ucs2', 139, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_lithuanian_ci', 'ucs2', 140, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_slovak_ci', 'ucs2', 141, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_spanish2_ci', 'ucs2', 142, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_roman_ci', 'ucs2', 143, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_persian_ci', 'ucs2', 144, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_esperanto_ci', 'ucs2', 145, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('ucs2_hungarian_ci', 'ucs2', 146, '', 'Yes', 8);
INSERT INTO `COLLATIONS` VALUES('cp866_general_ci', 'cp866', 36, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp866_bin', 'cp866', 68, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('keybcs2_general_ci', 'keybcs2', 37, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('keybcs2_bin', 'keybcs2', 73, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('macce_general_ci', 'macce', 38, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('macce_bin', 'macce', 43, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('macroman_general_ci', 'macroman', 39, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('macroman_bin', 'macroman', 53, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp852_general_ci', 'cp852', 40, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp852_bin', 'cp852', 81, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('latin7_estonian_cs', 'latin7', 20, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('latin7_general_ci', 'latin7', 41, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('latin7_general_cs', 'latin7', 42, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('latin7_bin', 'latin7', 79, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1251_bulgarian_ci', 'cp1251', 14, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1251_ukrainian_ci', 'cp1251', 23, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1251_bin', 'cp1251', 50, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1251_general_ci', 'cp1251', 51, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1251_general_cs', 'cp1251', 52, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1256_general_ci', 'cp1256', 57, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1256_bin', 'cp1256', 67, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1257_lithuanian_ci', 'cp1257', 29, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1257_bin', 'cp1257', 58, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp1257_general_ci', 'cp1257', 59, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('binary', 'binary', 63, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('geostd8_general_ci', 'geostd8', 92, 'Yes', '', 0);
INSERT INTO `COLLATIONS` VALUES('geostd8_bin', 'geostd8', 93, '', '', 0);
INSERT INTO `COLLATIONS` VALUES('cp932_japanese_ci', 'cp932', 95, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('cp932_bin', 'cp932', 96, '', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('eucjpms_japanese_ci', 'eucjpms', 97, 'Yes', 'Yes', 1);
INSERT INTO `COLLATIONS` VALUES('eucjpms_bin', 'eucjpms', 98, '', 'Yes', 1);

-- --------------------------------------------------------

--
-- Table structure for table `COLLATION_CHARACTER_SET_APPLICABILITY`
--

CREATE TEMPORARY TABLE `COLLATION_CHARACTER_SET_APPLICABILITY` (
  `COLLATION_NAME` varchar(64) NOT NULL default '',
  `CHARACTER_SET_NAME` varchar(64) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLLATION_CHARACTER_SET_APPLICABILITY`
--

INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('big5_chinese_ci', 'big5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('big5_bin', 'big5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('dec8_swedish_ci', 'dec8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('dec8_bin', 'dec8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp850_general_ci', 'cp850');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp850_bin', 'cp850');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hp8_english_ci', 'hp8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hp8_bin', 'hp8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8r_general_ci', 'koi8r');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8r_bin', 'koi8r');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_german1_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_swedish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_danish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_german2_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_bin', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_general_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_general_cs', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin1_spanish_ci', 'latin1');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_czech_cs', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_general_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_hungarian_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_croatian_ci', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin2_bin', 'latin2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('swe7_swedish_ci', 'swe7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('swe7_bin', 'swe7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ascii_general_ci', 'ascii');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ascii_bin', 'ascii');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ujis_japanese_ci', 'ujis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ujis_bin', 'ujis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('sjis_japanese_ci', 'sjis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('sjis_bin', 'sjis');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hebrew_general_ci', 'hebrew');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('hebrew_bin', 'hebrew');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('tis620_thai_ci', 'tis620');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('tis620_bin', 'tis620');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('euckr_korean_ci', 'euckr');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('euckr_bin', 'euckr');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8u_general_ci', 'koi8u');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('koi8u_bin', 'koi8u');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gb2312_chinese_ci', 'gb2312');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gb2312_bin', 'gb2312');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('greek_general_ci', 'greek');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('greek_bin', 'greek');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_general_ci', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_czech_cs', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_croatian_ci', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1250_bin', 'cp1250');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gbk_chinese_ci', 'gbk');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('gbk_bin', 'gbk');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin5_turkish_ci', 'latin5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin5_bin', 'latin5');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('armscii8_general_ci', 'armscii8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('armscii8_bin', 'armscii8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_general_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_bin', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_unicode_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_icelandic_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_latvian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_romanian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_slovenian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_polish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_estonian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_spanish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_swedish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_turkish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_czech_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_danish_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_lithuanian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_slovak_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_spanish2_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_roman_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_persian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_esperanto_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('utf8_hungarian_ci', 'utf8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_general_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_bin', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_unicode_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_icelandic_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_latvian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_romanian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_slovenian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_polish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_estonian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_spanish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_swedish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_turkish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_czech_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_danish_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_lithuanian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_slovak_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_spanish2_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_roman_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_persian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_esperanto_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('ucs2_hungarian_ci', 'ucs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp866_general_ci', 'cp866');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp866_bin', 'cp866');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('keybcs2_general_ci', 'keybcs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('keybcs2_bin', 'keybcs2');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macce_general_ci', 'macce');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macce_bin', 'macce');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macroman_general_ci', 'macroman');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('macroman_bin', 'macroman');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp852_general_ci', 'cp852');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp852_bin', 'cp852');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_estonian_cs', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_general_ci', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_general_cs', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('latin7_bin', 'latin7');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_bulgarian_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_ukrainian_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_bin', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_general_ci', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1251_general_cs', 'cp1251');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1256_general_ci', 'cp1256');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1256_bin', 'cp1256');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1257_lithuanian_ci', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1257_bin', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp1257_general_ci', 'cp1257');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('binary', 'binary');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('geostd8_general_ci', 'geostd8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('geostd8_bin', 'geostd8');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp932_japanese_ci', 'cp932');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('cp932_bin', 'cp932');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('eucjpms_japanese_ci', 'eucjpms');
INSERT INTO `COLLATION_CHARACTER_SET_APPLICABILITY` VALUES('eucjpms_bin', 'eucjpms');

-- --------------------------------------------------------

--
-- Table structure for table `COLUMNS`
--

CREATE TEMPORARY TABLE `COLUMNS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `ORDINAL_POSITION` bigint(21) NOT NULL default '0',
  `COLUMN_DEFAULT` longtext,
  `IS_NULLABLE` varchar(3) NOT NULL default '',
  `DATA_TYPE` varchar(64) NOT NULL default '',
  `CHARACTER_MAXIMUM_LENGTH` bigint(21) default NULL,
  `CHARACTER_OCTET_LENGTH` bigint(21) default NULL,
  `NUMERIC_PRECISION` bigint(21) default NULL,
  `NUMERIC_SCALE` bigint(21) default NULL,
  `CHARACTER_SET_NAME` varchar(64) default NULL,
  `COLLATION_NAME` varchar(64) default NULL,
  `COLUMN_TYPE` longtext NOT NULL,
  `COLUMN_KEY` varchar(3) NOT NULL default '',
  `EXTRA` varchar(20) NOT NULL default '',
  `PRIVILEGES` varchar(80) NOT NULL default '',
  `COLUMN_COMMENT` varchar(255) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLUMNS`
--

INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'CHARACTER_SET_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'DEFAULT_COLLATE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'DESCRIPTION', 3, '', 'NO', 'varchar', 60, 180, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(60)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'MAXLEN', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CLIENT', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'TOTAL_CONNECTIONS', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CONCURRENT_CONNECTIONS', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CONNECTED_TIME', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BUSY_TIME', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'CPU_TIME', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BYTES_RECEIVED', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BYTES_SENT', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'BINLOG_BYTES_WRITTEN', 9, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ROWS_FETCHED', 10, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ROWS_UPDATED', 11, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'TABLE_ROWS_READ', 12, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'SELECT_COMMANDS', 13, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'UPDATE_COMMANDS', 14, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'OTHER_COMMANDS', 15, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'COMMIT_TRANSACTIONS', 16, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ROLLBACK_TRANSACTIONS', 17, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'DENIED_CONNECTIONS', 18, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'LOST_CONNECTIONS', 19, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'ACCESS_DENIED', 20, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'EMPTY_QUERIES', 21, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'COLLATION_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'CHARACTER_SET_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'ID', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'IS_DEFAULT', 4, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'IS_COMPILED', 5, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATIONS', 'SORTLEN', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'COLLATION_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'CHARACTER_SET_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'ORDINAL_POSITION', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_DEFAULT', 6, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'IS_NULLABLE', 7, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'DATA_TYPE', 8, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'CHARACTER_MAXIMUM_LENGTH', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'CHARACTER_OCTET_LENGTH', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'NUMERIC_PRECISION', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'NUMERIC_SCALE', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'CHARACTER_SET_NAME', 13, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLLATION_NAME', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_TYPE', 15, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_KEY', 16, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'EXTRA', 17, '', 'NO', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'PRIVILEGES', 18, '', 'NO', 'varchar', 80, 240, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(80)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMNS', 'COLUMN_COMMENT', 19, '', 'NO', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'TABLE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'COLUMN_NAME', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'PRIVILEGE_TYPE', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'IS_GRANTABLE', 7, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'BLOCK_NUM', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'SPACE', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'OFFSET', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'RECORDS', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'DATASIZE', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'FLUSH_TYPE', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'FIX_COUNT', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'LRU_POSITION', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'PAGE_TYPE_ID', 9, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'PAGE_TYPE', 10, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'INDEX_NAME', 11, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'TABLE_SCHEMA', 12, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'TABLE_NAME', 13, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'TABLE_SCHEMA', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'TABLE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'INDEX_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'ROWS_READ', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'CONSTRAINT_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_CATALOG', 4, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_SCHEMA', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'TABLE_NAME', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'COLUMN_NAME', 7, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'ORDINAL_POSITION', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'POSITION_IN_UNIQUE_CONSTRAINT', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_TABLE_SCHEMA', 10, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_TABLE_NAME', 11, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'REFERENCED_COLUMN_NAME', 12, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(4)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'USER', 2, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'HOST', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'DB', 4, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'COMMAND', 5, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'TIME', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'STATE', 7, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'INFO', 8, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'TIME_MS', 9, '0.000', 'NO', 'decimal', NULL, NULL, 22, 3, NULL, NULL, 'decimal(22,3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'QUERY_ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SEQ', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'STATE', 3, '', 'NO', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'DURATION', 4, '0.000000', 'NO', 'decimal', NULL, NULL, 9, 6, NULL, NULL, 'decimal(9,6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CPU_USER', 5, NULL, 'YES', 'decimal', NULL, NULL, 9, 6, NULL, NULL, 'decimal(9,6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CPU_SYSTEM', 6, NULL, 'YES', 'decimal', NULL, NULL, 9, 6, NULL, NULL, 'decimal(9,6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CONTEXT_VOLUNTARY', 7, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'CONTEXT_INVOLUNTARY', 8, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'BLOCK_OPS_IN', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'BLOCK_OPS_OUT', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'MESSAGES_SENT', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'MESSAGES_RECEIVED', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'PAGE_FAULTS_MAJOR', 13, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'PAGE_FAULTS_MINOR', 14, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SWAPS', 15, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SOURCE_FUNCTION', 16, NULL, 'YES', 'varchar', 30, 90, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(30)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SOURCE_FILE', 17, NULL, 'YES', 'varchar', 20, 60, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'PROFILING', 'SOURCE_LINE', 18, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(20)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SPECIFIC_NAME', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_TYPE', 5, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'DTD_IDENTIFIER', 6, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_BODY', 7, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_DEFINITION', 8, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'EXTERNAL_NAME', 9, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'EXTERNAL_LANGUAGE', 10, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'PARAMETER_STYLE', 11, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'IS_DETERMINISTIC', 12, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SQL_DATA_ACCESS', 13, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SQL_PATH', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SECURITY_TYPE', 15, '', 'NO', 'varchar', 7, 21, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'CREATED', 16, '0000-00-00 00:00:00', 'NO', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'LAST_ALTERED', 17, '0000-00-00 00:00:00', 'NO', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'SQL_MODE', 18, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'ROUTINE_COMMENT', 19, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'ROUTINES', 'DEFINER', 20, '', 'NO', 'varchar', 77, 231, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(77)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'CATALOG_NAME', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'SCHEMA_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'DEFAULT_CHARACTER_SET_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'DEFAULT_COLLATION_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMATA', 'SQL_PATH', 5, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'PRIVILEGE_TYPE', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'IS_GRANTABLE', 5, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'NON_UNIQUE', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(1)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'INDEX_SCHEMA', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'INDEX_NAME', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'SEQ_IN_INDEX', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(2)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'COLUMN_NAME', 8, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'COLLATION', 9, NULL, 'YES', 'varchar', 1, 3, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(1)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'CARDINALITY', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'SUB_PART', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'PACKED', 12, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'NULLABLE', 13, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'INDEX_TYPE', 14, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'STATISTICS', 'COMMENT', 15, NULL, 'YES', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_TYPE', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'ENGINE', 5, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'VERSION', 6, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'ROW_FORMAT', 7, NULL, 'YES', 'varchar', 10, 30, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(10)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_ROWS', 8, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'AVG_ROW_LENGTH', 9, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'DATA_LENGTH', 10, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'MAX_DATA_LENGTH', 11, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'INDEX_LENGTH', 12, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'DATA_FREE', 13, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'AUTO_INCREMENT', 14, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CREATE_TIME', 15, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'UPDATE_TIME', 16, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CHECK_TIME', 17, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_COLLATION', 18, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CHECKSUM', 19, NULL, 'YES', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'CREATE_OPTIONS', 20, NULL, 'YES', 'varchar', 255, 765, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(255)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLES', 'TABLE_COMMENT', 21, '', 'NO', 'varchar', 80, 240, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(80)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'TABLE_SCHEMA', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'TABLE_NAME', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'CONSTRAINT_TYPE', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_SCHEMA', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'TABLE_NAME', 4, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'PRIVILEGE_TYPE', 5, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'IS_GRANTABLE', 6, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'TABLE_SCHEMA', 1, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'TABLE_NAME', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'ROWS_READ', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'ROWS_CHANGED', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'ROWS_CHANGED_X_INDEXES', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'TRIGGER_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_MANIPULATION', 4, '', 'NO', 'varchar', 6, 18, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_CATALOG', 5, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_SCHEMA', 6, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'EVENT_OBJECT_TABLE', 7, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_ORDER', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(4)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_CONDITION', 9, NULL, 'YES', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_STATEMENT', 10, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_ORIENTATION', 11, '', 'NO', 'varchar', 9, 27, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(9)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_TIMING', 12, '', 'NO', 'varchar', 6, 18, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(6)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_OLD_TABLE', 13, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_NEW_TABLE', 14, NULL, 'YES', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_OLD_ROW', 15, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'ACTION_REFERENCE_NEW_ROW', 16, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'CREATED', 17, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'SQL_MODE', 18, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'TRIGGERS', 'DEFINER', 19, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'GRANTEE', 1, '', 'NO', 'varchar', 81, 243, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(81)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'TABLE_CATALOG', 2, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'PRIVILEGE_TYPE', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'IS_GRANTABLE', 4, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'USER', 1, '', 'NO', 'varchar', 16, 48, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(16)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'TOTAL_CONNECTIONS', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'CONCURRENT_CONNECTIONS', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'CONNECTED_TIME', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BUSY_TIME', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'CPU_TIME', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BYTES_RECEIVED', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BYTES_SENT', 8, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'BINLOG_BYTES_WRITTEN', 9, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ROWS_FETCHED', 10, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ROWS_UPDATED', 11, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'TABLE_ROWS_READ', 12, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'SELECT_COMMANDS', 13, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'UPDATE_COMMANDS', 14, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'OTHER_COMMANDS', 15, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'COMMIT_TRANSACTIONS', 16, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ROLLBACK_TRANSACTIONS', 17, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'DENIED_CONNECTIONS', 18, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'LOST_CONNECTIONS', 19, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'ACCESS_DENIED', 20, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'EMPTY_QUERIES', 21, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'TABLE_CATALOG', 1, NULL, 'YES', 'varchar', 512, 1536, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(512)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'TABLE_SCHEMA', 2, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'TABLE_NAME', 3, '', 'NO', 'varchar', 64, 192, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(64)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'VIEW_DEFINITION', 4, NULL, 'NO', 'longtext', 4294967295, 4294967295, NULL, NULL, 'utf8', 'utf8_general_ci', 'longtext', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'CHECK_OPTION', 5, '', 'NO', 'varchar', 8, 24, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(8)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'IS_UPDATABLE', 6, '', 'NO', 'varchar', 3, 9, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(3)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'DEFINER', 7, '', 'NO', 'varchar', 77, 231, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(77)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'VIEWS', 'SECURITY_TYPE', 8, '', 'NO', 'varchar', 7, 21, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(7)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'SPACE', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'OFFSET', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'INDEX_ID', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'TABLE_NAME', 4, '', 'NO', 'varchar', 32, 96, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(32)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'INDEX_NAME', 5, '', 'NO', 'varchar', 32, 96, NULL, NULL, 'utf8', 'utf8_general_ci', 'varchar(32)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'N_READ', 6, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'N_WRITE', 7, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(11)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'RSEG_ID', 1, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'SPACE_ID', 2, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'PAGE_NO', 3, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'MAX_SIZE', 4, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'CURR_SIZE', 5, '0', 'NO', 'bigint', NULL, NULL, 19, 0, NULL, NULL, 'bigint(21)', '', '', 'select', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'account', 'account_number', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'account', 'balance', 2, NULL, 'YES', 'float', NULL, NULL, 12, NULL, NULL, NULL, 'float', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'account', 'option', 3, NULL, 'YES', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'account', 'type', 4, NULL, 'YES', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'account', 'client_id', 5, NULL, 'YES', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'branch_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'branch_name', 2, NULL, 'YES', 'text', 65535, 65535, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'text', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'address', 3, NULL, 'YES', 'varchar', 255, 255, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'city', 4, NULL, 'YES', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'phone', 5, NULL, 'YES', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'fax', 6, NULL, 'YES', 'varchar', 100, 100, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(100)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'opening_date', 7, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'branch', 'manager_id', 8, NULL, 'YES', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'client', 'client_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'client', 'name', 2, NULL, 'YES', 'varchar', 255, 255, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'client', 'address', 3, NULL, 'YES', 'varchar', 255, 255, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'client', 'dob', 4, NULL, 'YES', 'date', NULL, NULL, NULL, NULL, NULL, NULL, 'date', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'client', 'joining_date', 5, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'client', 'password', 6, '''12345''', 'NO', 'varchar', 64, 64, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(64)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'clientele', 'client_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'clientele', 'branch_id', 2, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'employee_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'title', 2, NULL, 'YES', 'varchar', 255, 255, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'name', 3, NULL, 'YES', 'varchar', 255, 255, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'address', 4, NULL, 'YES', 'varchar', 255, 255, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(255)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'salary', 5, NULL, 'YES', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'start_date', 6, NULL, 'YES', 'datetime', NULL, NULL, NULL, NULL, NULL, NULL, 'datetime', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'branch_id', 7, NULL, 'YES', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'employee', 'password', 8, '''12345''', 'NO', 'varchar', 64, 64, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(64)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'need', 'need', 1, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', 'PRI', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'plan', 'option_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'plan', 'option', 2, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'plan', 'transaction_limit', 3, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(9)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'plan', 'credit_limit', 4, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(9)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'plan', 'charge', 5, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(9)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'rate', 'type_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'rate', 'type', 2, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'rate', 'percentage', 3, NULL, 'NO', 'tinyint', NULL, NULL, 3, 0, NULL, NULL, 'tinyint(4)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'rate', 'service', 4, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'rate', 'need', 5, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'service', 'service', 1, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', 'PRI', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'transaction', 'transaction_id', 1, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'PRI', 'auto_increment', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'transaction', 'date', 2, 'CURRENT_TIMESTAMP', 'NO', 'timestamp', NULL, NULL, NULL, NULL, NULL, NULL, 'timestamp', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'transaction', 'amount', 3, NULL, 'NO', 'decimal', NULL, NULL, 10, 0, NULL, NULL, 'decimal(10,0)', '', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'transaction', 'type', 4, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'transaction', 'account_number', 5, NULL, 'NO', 'mediumint', NULL, NULL, 7, 0, NULL, NULL, 'mediumint(8) unsigned', 'MUL', '', 'select,insert,update', '');
INSERT INTO `COLUMNS` VALUES(NULL, 'bankc35320110808', 'type', 'type', 1, NULL, 'NO', 'varchar', 50, 50, NULL, NULL, 'latin1', 'latin1_swedish_ci', 'varchar(50)', 'PRI', '', 'select,insert,update', '');

-- --------------------------------------------------------

--
-- Table structure for table `COLUMN_PRIVILEGES`
--

CREATE TEMPORARY TABLE `COLUMN_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `COLUMN_PRIVILEGES`
--


-- --------------------------------------------------------

--
-- Table structure for table `INNODB_BUFFER_POOL_CONTENT`
--

CREATE TEMPORARY TABLE `INNODB_BUFFER_POOL_CONTENT` (
  `BLOCK_NUM` bigint(21) NOT NULL default '0',
  `SPACE` bigint(21) NOT NULL default '0',
  `OFFSET` bigint(21) NOT NULL default '0',
  `RECORDS` bigint(21) NOT NULL default '0',
  `DATASIZE` bigint(21) NOT NULL default '0',
  `FLUSH_TYPE` bigint(21) NOT NULL default '0',
  `FIX_COUNT` bigint(21) NOT NULL default '0',
  `LRU_POSITION` bigint(21) NOT NULL default '0',
  `PAGE_TYPE_ID` bigint(21) NOT NULL default '0',
  `PAGE_TYPE` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INNODB_BUFFER_POOL_CONTENT`
--

-- in use (#1227 - Access denied; you need the PROCESS privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `INDEX_STATISTICS`
--

CREATE TEMPORARY TABLE `INDEX_STATISTICS` (
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `ROWS_READ` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INDEX_STATISTICS`
--


-- --------------------------------------------------------

--
-- Table structure for table `KEY_COLUMN_USAGE`
--

CREATE TEMPORARY TABLE `KEY_COLUMN_USAGE` (
  `CONSTRAINT_CATALOG` varchar(512) default NULL,
  `CONSTRAINT_SCHEMA` varchar(64) NOT NULL default '',
  `CONSTRAINT_NAME` varchar(64) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `ORDINAL_POSITION` bigint(10) NOT NULL default '0',
  `POSITION_IN_UNIQUE_CONSTRAINT` bigint(10) default NULL,
  `REFERENCED_TABLE_SCHEMA` varchar(64) default NULL,
  `REFERENCED_TABLE_NAME` varchar(64) default NULL,
  `REFERENCED_COLUMN_NAME` varchar(64) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `KEY_COLUMN_USAGE`
--

INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'account', 'account_number', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'account_ibfk_1', NULL, 'bankc35320110808', 'account', 'option', 1, 1, 'bankc35320110808', 'plan', 'option_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'account_ibfk_2', NULL, 'bankc35320110808', 'account', 'type', 1, 1, 'bankc35320110808', 'rate', 'type_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'account_ibfk_3', NULL, 'bankc35320110808', 'account', 'client_id', 1, 1, 'bankc35320110808', 'client', 'client_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'branch', 'branch_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'branch_ibfk_1', NULL, 'bankc35320110808', 'branch', 'manager_id', 1, 1, 'bankc35320110808', 'employee', 'employee_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'client', 'client_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'clientele', 'client_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'clientele', 'branch_id', 2, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'clientele_ibfk_1', NULL, 'bankc35320110808', 'clientele', 'client_id', 1, 1, 'bankc35320110808', 'client', 'client_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'clientele_ibfk_2', NULL, 'bankc35320110808', 'clientele', 'branch_id', 1, 1, 'bankc35320110808', 'branch', 'branch_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'employee', 'employee_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'employee_ibfk_1', NULL, 'bankc35320110808', 'employee', 'branch_id', 1, 1, 'bankc35320110808', 'branch', 'branch_id');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'need', 'need', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'plan', 'option_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'rate', 'type_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'rate_ibfk_1', NULL, 'bankc35320110808', 'rate', 'need', 1, 1, 'bankc35320110808', 'need', 'need');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'rate_ibfk_2', NULL, 'bankc35320110808', 'rate', 'service', 1, 1, 'bankc35320110808', 'service', 'service');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'service', 'service', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'transaction', 'transaction_id', 1, NULL, NULL, NULL, NULL);
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'transaction_ibfk_1', NULL, 'bankc35320110808', 'transaction', 'type', 1, 1, 'bankc35320110808', 'type', 'type');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'transaction_ibfk_2', NULL, 'bankc35320110808', 'transaction', 'account_number', 1, 1, 'bankc35320110808', 'account', 'account_number');
INSERT INTO `KEY_COLUMN_USAGE` VALUES(NULL, 'bankc35320110808', 'PRIMARY', NULL, 'bankc35320110808', 'type', 'type', 1, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PROCESSLIST`
--

CREATE TEMPORARY TABLE `PROCESSLIST` (
  `ID` bigint(4) NOT NULL default '0',
  `USER` varchar(16) NOT NULL default '',
  `HOST` varchar(64) NOT NULL default '',
  `DB` varchar(64) default NULL,
  `COMMAND` varchar(16) NOT NULL default '',
  `TIME` bigint(7) NOT NULL default '0',
  `STATE` varchar(64) default NULL,
  `INFO` longtext,
  `TIME_MS` decimal(22,3) NOT NULL default '0.000'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PROCESSLIST`
--

INSERT INTO `PROCESSLIST` VALUES(2335595, 'bankc35320110808', '72.167.233.37:49540', NULL, 'Query', 0, 'executing', 'SELECT * FROM `information_schema`.`PROCESSLIST`', 1.105);

-- --------------------------------------------------------

--
-- Table structure for table `PROFILING`
--

CREATE TEMPORARY TABLE `PROFILING` (
  `QUERY_ID` bigint(20) NOT NULL default '0',
  `SEQ` bigint(20) NOT NULL default '0',
  `STATE` varchar(30) NOT NULL default '',
  `DURATION` decimal(9,6) NOT NULL default '0.000000',
  `CPU_USER` decimal(9,6) default NULL,
  `CPU_SYSTEM` decimal(9,6) default NULL,
  `CONTEXT_VOLUNTARY` bigint(20) default NULL,
  `CONTEXT_INVOLUNTARY` bigint(20) default NULL,
  `BLOCK_OPS_IN` bigint(20) default NULL,
  `BLOCK_OPS_OUT` bigint(20) default NULL,
  `MESSAGES_SENT` bigint(20) default NULL,
  `MESSAGES_RECEIVED` bigint(20) default NULL,
  `PAGE_FAULTS_MAJOR` bigint(20) default NULL,
  `PAGE_FAULTS_MINOR` bigint(20) default NULL,
  `SWAPS` bigint(20) default NULL,
  `SOURCE_FUNCTION` varchar(30) default NULL,
  `SOURCE_FILE` varchar(20) default NULL,
  `SOURCE_LINE` bigint(20) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `PROFILING`
--

-- in use (#1289 - The 'SHOW PROFILE' feature is disabled; you need MySQL built with 'enable-profiling' to have it working)

-- --------------------------------------------------------

--
-- Table structure for table `ROUTINES`
--

CREATE TEMPORARY TABLE `ROUTINES` (
  `SPECIFIC_NAME` varchar(64) NOT NULL default '',
  `ROUTINE_CATALOG` varchar(512) default NULL,
  `ROUTINE_SCHEMA` varchar(64) NOT NULL default '',
  `ROUTINE_NAME` varchar(64) NOT NULL default '',
  `ROUTINE_TYPE` varchar(9) NOT NULL default '',
  `DTD_IDENTIFIER` varchar(64) default NULL,
  `ROUTINE_BODY` varchar(8) NOT NULL default '',
  `ROUTINE_DEFINITION` longtext,
  `EXTERNAL_NAME` varchar(64) default NULL,
  `EXTERNAL_LANGUAGE` varchar(64) default NULL,
  `PARAMETER_STYLE` varchar(8) NOT NULL default '',
  `IS_DETERMINISTIC` varchar(3) NOT NULL default '',
  `SQL_DATA_ACCESS` varchar(64) NOT NULL default '',
  `SQL_PATH` varchar(64) default NULL,
  `SECURITY_TYPE` varchar(7) NOT NULL default '',
  `CREATED` datetime NOT NULL default '0000-00-00 00:00:00',
  `LAST_ALTERED` datetime NOT NULL default '0000-00-00 00:00:00',
  `SQL_MODE` longtext NOT NULL,
  `ROUTINE_COMMENT` varchar(64) NOT NULL default '',
  `DEFINER` varchar(77) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ROUTINES`
--


-- --------------------------------------------------------

--
-- Table structure for table `SCHEMATA`
--

CREATE TEMPORARY TABLE `SCHEMATA` (
  `CATALOG_NAME` varchar(512) default NULL,
  `SCHEMA_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_CHARACTER_SET_NAME` varchar(64) NOT NULL default '',
  `DEFAULT_COLLATION_NAME` varchar(64) NOT NULL default '',
  `SQL_PATH` varchar(512) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `SCHEMATA`
--

INSERT INTO `SCHEMATA` VALUES(NULL, 'information_schema', 'utf8', 'utf8_general_ci', NULL);
INSERT INTO `SCHEMATA` VALUES(NULL, 'bankc35320110808', 'utf8', 'utf8_general_ci', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SCHEMA_PRIVILEGES`
--

CREATE TEMPORARY TABLE `SCHEMA_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `SCHEMA_PRIVILEGES`
--

INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'SELECT', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'INSERT', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'UPDATE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'DELETE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'CREATE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'DROP', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'INDEX', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'ALTER', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'CREATE TEMPORARY TABLES', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'LOCK TABLES', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'EXECUTE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'CREATE VIEW', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'SHOW VIEW', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'CREATE ROUTINE', 'NO');
INSERT INTO `SCHEMA_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'bankc35320110808', 'ALTER ROUTINE', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `STATISTICS`
--

CREATE TEMPORARY TABLE `STATISTICS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `NON_UNIQUE` bigint(1) NOT NULL default '0',
  `INDEX_SCHEMA` varchar(64) NOT NULL default '',
  `INDEX_NAME` varchar(64) NOT NULL default '',
  `SEQ_IN_INDEX` bigint(2) NOT NULL default '0',
  `COLUMN_NAME` varchar(64) NOT NULL default '',
  `COLLATION` varchar(1) default NULL,
  `CARDINALITY` bigint(21) default NULL,
  `SUB_PART` bigint(3) default NULL,
  `PACKED` varchar(10) default NULL,
  `NULLABLE` varchar(3) NOT NULL default '',
  `INDEX_TYPE` varchar(16) NOT NULL default '',
  `COMMENT` varchar(16) default NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `STATISTICS`
--

INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'account', 0, 'bankc35320110808', 'PRIMARY', 1, 'account_number', 'A', 72, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'account', 1, 'bankc35320110808', 'option', 1, 'option', 'A', 6, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'account', 1, 'bankc35320110808', 'type', 1, 'type', 'A', 24, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'account', 1, 'bankc35320110808', 'client_id', 1, 'client_id', 'A', 72, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'branch', 0, 'bankc35320110808', 'PRIMARY', 1, 'branch_id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'branch', 1, 'bankc35320110808', 'manager_id', 1, 'manager_id', 'A', 2, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'client', 0, 'bankc35320110808', 'PRIMARY', 1, 'client_id', 'A', 50, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'clientele', 0, 'bankc35320110808', 'PRIMARY', 1, 'client_id', 'A', 50, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'clientele', 0, 'bankc35320110808', 'PRIMARY', 2, 'branch_id', 'A', 50, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'clientele', 1, 'bankc35320110808', 'branch_id', 1, 'branch_id', 'A', 25, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'employee', 0, 'bankc35320110808', 'PRIMARY', 1, 'employee_id', 'A', 100, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'employee', 1, 'bankc35320110808', 'branch_id', 1, 'branch_id', 'A', 25, NULL, NULL, 'YES', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'need', 0, 'bankc35320110808', 'PRIMARY', 1, 'need', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'plan', 0, 'bankc35320110808', 'PRIMARY', 1, 'option_id', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'rate', 0, 'bankc35320110808', 'PRIMARY', 1, 'type_id', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'rate', 1, 'bankc35320110808', 'need', 1, 'need', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'rate', 1, 'bankc35320110808', 'service', 1, 'service', 'A', 2, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'service', 0, 'bankc35320110808', 'PRIMARY', 1, 'service', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'transaction', 0, 'bankc35320110808', 'PRIMARY', 1, 'transaction_id', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'transaction', 1, 'bankc35320110808', 'type', 1, 'type', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'transaction', 1, 'bankc35320110808', 'account_number', 1, 'account_number', 'A', 3, NULL, NULL, '', 'BTREE', '');
INSERT INTO `STATISTICS` VALUES(NULL, 'bankc35320110808', 'type', 0, 'bankc35320110808', 'PRIMARY', 1, 'type', 'A', 2, NULL, NULL, '', 'BTREE', '');

-- --------------------------------------------------------

--
-- Table structure for table `TABLES`
--

CREATE TEMPORARY TABLE `TABLES` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `TABLE_TYPE` varchar(64) NOT NULL default '',
  `ENGINE` varchar(64) default NULL,
  `VERSION` bigint(21) default NULL,
  `ROW_FORMAT` varchar(10) default NULL,
  `TABLE_ROWS` bigint(21) default NULL,
  `AVG_ROW_LENGTH` bigint(21) default NULL,
  `DATA_LENGTH` bigint(21) default NULL,
  `MAX_DATA_LENGTH` bigint(21) default NULL,
  `INDEX_LENGTH` bigint(21) default NULL,
  `DATA_FREE` bigint(21) default NULL,
  `AUTO_INCREMENT` bigint(21) default NULL,
  `CREATE_TIME` datetime default NULL,
  `UPDATE_TIME` datetime default NULL,
  `CHECK_TIME` datetime default NULL,
  `TABLE_COLLATION` varchar(64) default NULL,
  `CHECKSUM` bigint(21) default NULL,
  `CREATE_OPTIONS` varchar(255) default NULL,
  `TABLE_COMMENT` varchar(80) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLES`
--

INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'CHARACTER_SETS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 576, 0, 8388288, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=14563', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'CLIENT_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 354, 0, 8388384, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=23696', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLLATIONS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 423, 0, 8388513, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=19831', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLLATION_CHARACTER_SET_APPLICABILITY', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 387, 0, 8388225, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=21675', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLUMNS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2011-08-08 16:09:12', '2011-08-08 16:09:12', NULL, 'utf8_general_ci', NULL, 'max_rows=2178', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'COLUMN_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2565, 0, 8387550, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3270', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INNODB_BUFFER_POOL_CONTENT', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 845, 0, 8388315, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=9927', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INDEX_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 588, 0, 8388408, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=14266', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'KEY_COLUMN_USAGE', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 4637, 0, 8388333, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=1809', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'PROCESSLIST', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2011-08-08 16:09:12', '2011-08-08 16:09:12', NULL, 'utf8_general_ci', NULL, 'max_rows=11699', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'PROFILING', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 356, 0, 8388428, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=23563', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'ROUTINES', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2011-08-08 16:09:12', '2011-08-08 16:09:12', NULL, 'utf8_general_ci', NULL, 'max_rows=2293', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'SCHEMATA', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 3656, 0, 8386864, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2294', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'SCHEMA_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2179, 0, 8386971, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3849', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2679, 0, 8387949, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3131', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 3641, 0, 8385223, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=2303', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLE_CONSTRAINTS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2504, 0, 8388400, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3350', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLE_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 2372, 0, 8387392, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=3536', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TABLE_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 411, 0, 8388510, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=20410', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'TRIGGERS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2011-08-08 16:09:12', '2011-08-08 16:09:12', NULL, 'utf8_general_ci', NULL, 'max_rows=1913', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'USER_PRIVILEGES', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 1986, 0, 8386878, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=4223', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'USER_STATISTICS', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 210, 0, 8388450, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=39945', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'VIEWS', 'SYSTEM VIEW', 'MyISAM', 0, 'Dynamic', NULL, 0, 0, 281474976710655, 1024, 0, NULL, '2011-08-08 16:09:12', '2011-08-08 16:09:12', NULL, 'utf8_general_ci', NULL, 'max_rows=3768', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INNODB_IO_PATTERN', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 235, 0, 8388560, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=35696', '');
INSERT INTO `TABLES` VALUES(NULL, 'information_schema', 'INNODB_RSEG', 'SYSTEM VIEW', 'MEMORY', 0, 'Fixed', NULL, 41, 0, 8388600, 0, 0, NULL, NULL, NULL, NULL, 'utf8_general_ci', NULL, 'max_rows=204600', '');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'account', 'BASE TABLE', 'InnoDB', 10, 'Compact', 72, 227, 16384, 0, 49152, 0, 84, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB; (`option`) REFER `bankc35320110808/plan`(`option_id`); (`type');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'branch', 'BASE TABLE', 'InnoDB', 10, 'Compact', 12, 1365, 16384, 0, 16384, 0, 14, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB; (`manager_id`) REFER `bankc35320110808/employee`(`employee_id');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'client', 'BASE TABLE', 'InnoDB', 10, 'Compact', 50, 327, 16384, 0, 0, 0, 52, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'clientele', 'BASE TABLE', 'InnoDB', 10, 'Compact', 50, 327, 16384, 0, 16384, 0, NULL, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB; (`client_id`) REFER `bankc35320110808/client`(`client_id`); (');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'employee', 'BASE TABLE', 'InnoDB', 10, 'Compact', 100, 163, 16384, 0, 16384, 0, 101, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB; (`branch_id`) REFER `bankc35320110808/branch`(`branch_id`)');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'need', 'BASE TABLE', 'InnoDB', 10, 'Compact', 3, 5461, 16384, 0, 0, 0, NULL, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'plan', 'BASE TABLE', 'InnoDB', 10, 'Compact', 3, 5461, 16384, 0, 0, 0, 4, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'rate', 'BASE TABLE', 'InnoDB', 10, 'Compact', 10, 1638, 16384, 0, 32768, 0, 11, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB; (`need`) REFER `bankc35320110808/need`(`need`); (`service`) R');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'service', 'BASE TABLE', 'InnoDB', 10, 'Compact', 3, 5461, 16384, 0, 0, 0, NULL, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'transaction', 'BASE TABLE', 'InnoDB', 10, 'Compact', 23, 712, 16384, 0, 32768, 0, 26, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB; (`type`) REFER `bankc35320110808/type`(`type`); (`account_num');
INSERT INTO `TABLES` VALUES(NULL, 'bankc35320110808', 'type', 'BASE TABLE', 'InnoDB', 10, 'Compact', 2, 8192, 16384, 0, 0, 0, NULL, '2011-08-05 22:20:33', NULL, NULL, 'latin1_swedish_ci', NULL, '', 'InnoDB free: 0 kB');

-- --------------------------------------------------------

--
-- Table structure for table `TABLE_CONSTRAINTS`
--

CREATE TEMPORARY TABLE `TABLE_CONSTRAINTS` (
  `CONSTRAINT_CATALOG` varchar(512) default NULL,
  `CONSTRAINT_SCHEMA` varchar(64) NOT NULL default '',
  `CONSTRAINT_NAME` varchar(64) NOT NULL default '',
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `CONSTRAINT_TYPE` varchar(64) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE_CONSTRAINTS`
--

INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'account', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'account_ibfk_1', 'bankc35320110808', 'account', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'account_ibfk_2', 'bankc35320110808', 'account', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'account_ibfk_3', 'bankc35320110808', 'account', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'branch', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'branch_ibfk_1', 'bankc35320110808', 'branch', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'client', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'clientele', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'clientele_ibfk_1', 'bankc35320110808', 'clientele', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'clientele_ibfk_2', 'bankc35320110808', 'clientele', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'employee', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'employee_ibfk_1', 'bankc35320110808', 'employee', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'need', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'plan', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'rate', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'rate_ibfk_1', 'bankc35320110808', 'rate', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'rate_ibfk_2', 'bankc35320110808', 'rate', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'service', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'transaction', 'PRIMARY KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'transaction_ibfk_1', 'bankc35320110808', 'transaction', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'transaction_ibfk_2', 'bankc35320110808', 'transaction', 'FOREIGN KEY');
INSERT INTO `TABLE_CONSTRAINTS` VALUES(NULL, 'bankc35320110808', 'PRIMARY', 'bankc35320110808', 'type', 'PRIMARY KEY');

-- --------------------------------------------------------

--
-- Table structure for table `TABLE_PRIVILEGES`
--

CREATE TEMPORARY TABLE `TABLE_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE_PRIVILEGES`
--


-- --------------------------------------------------------

--
-- Table structure for table `TABLE_STATISTICS`
--

CREATE TEMPORARY TABLE `TABLE_STATISTICS` (
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `ROWS_READ` bigint(21) NOT NULL default '0',
  `ROWS_CHANGED` bigint(21) NOT NULL default '0',
  `ROWS_CHANGED_X_INDEXES` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TABLE_STATISTICS`
--


-- --------------------------------------------------------

--
-- Table structure for table `TRIGGERS`
--

CREATE TEMPORARY TABLE `TRIGGERS` (
  `TRIGGER_CATALOG` varchar(512) default NULL,
  `TRIGGER_SCHEMA` varchar(64) NOT NULL default '',
  `TRIGGER_NAME` varchar(64) NOT NULL default '',
  `EVENT_MANIPULATION` varchar(6) NOT NULL default '',
  `EVENT_OBJECT_CATALOG` varchar(512) default NULL,
  `EVENT_OBJECT_SCHEMA` varchar(64) NOT NULL default '',
  `EVENT_OBJECT_TABLE` varchar(64) NOT NULL default '',
  `ACTION_ORDER` bigint(4) NOT NULL default '0',
  `ACTION_CONDITION` longtext,
  `ACTION_STATEMENT` longtext NOT NULL,
  `ACTION_ORIENTATION` varchar(9) NOT NULL default '',
  `ACTION_TIMING` varchar(6) NOT NULL default '',
  `ACTION_REFERENCE_OLD_TABLE` varchar(64) default NULL,
  `ACTION_REFERENCE_NEW_TABLE` varchar(64) default NULL,
  `ACTION_REFERENCE_OLD_ROW` varchar(3) NOT NULL default '',
  `ACTION_REFERENCE_NEW_ROW` varchar(3) NOT NULL default '',
  `CREATED` datetime default NULL,
  `SQL_MODE` longtext NOT NULL,
  `DEFINER` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `TRIGGERS`
--


-- --------------------------------------------------------

--
-- Table structure for table `USER_PRIVILEGES`
--

CREATE TEMPORARY TABLE `USER_PRIVILEGES` (
  `GRANTEE` varchar(81) NOT NULL default '',
  `TABLE_CATALOG` varchar(512) default NULL,
  `PRIVILEGE_TYPE` varchar(64) NOT NULL default '',
  `IS_GRANTABLE` varchar(3) NOT NULL default ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `USER_PRIVILEGES`
--

INSERT INTO `USER_PRIVILEGES` VALUES('''bankc35320110808''@''%''', NULL, 'USAGE', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `USER_STATISTICS`
--

CREATE TEMPORARY TABLE `USER_STATISTICS` (
  `USER` varchar(16) NOT NULL default '',
  `TOTAL_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONCURRENT_CONNECTIONS` bigint(21) NOT NULL default '0',
  `CONNECTED_TIME` bigint(21) NOT NULL default '0',
  `BUSY_TIME` bigint(21) NOT NULL default '0',
  `CPU_TIME` bigint(21) NOT NULL default '0',
  `BYTES_RECEIVED` bigint(21) NOT NULL default '0',
  `BYTES_SENT` bigint(21) NOT NULL default '0',
  `BINLOG_BYTES_WRITTEN` bigint(21) NOT NULL default '0',
  `ROWS_FETCHED` bigint(21) NOT NULL default '0',
  `ROWS_UPDATED` bigint(21) NOT NULL default '0',
  `TABLE_ROWS_READ` bigint(21) NOT NULL default '0',
  `SELECT_COMMANDS` bigint(21) NOT NULL default '0',
  `UPDATE_COMMANDS` bigint(21) NOT NULL default '0',
  `OTHER_COMMANDS` bigint(21) NOT NULL default '0',
  `COMMIT_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `ROLLBACK_TRANSACTIONS` bigint(21) NOT NULL default '0',
  `DENIED_CONNECTIONS` bigint(21) NOT NULL default '0',
  `LOST_CONNECTIONS` bigint(21) NOT NULL default '0',
  `ACCESS_DENIED` bigint(21) NOT NULL default '0',
  `EMPTY_QUERIES` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `USER_STATISTICS`
--

-- in use (#1227 - Access denied; you need the PROCESS,SUPER privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `VIEWS`
--

CREATE TEMPORARY TABLE `VIEWS` (
  `TABLE_CATALOG` varchar(512) default NULL,
  `TABLE_SCHEMA` varchar(64) NOT NULL default '',
  `TABLE_NAME` varchar(64) NOT NULL default '',
  `VIEW_DEFINITION` longtext NOT NULL,
  `CHECK_OPTION` varchar(8) NOT NULL default '',
  `IS_UPDATABLE` varchar(3) NOT NULL default '',
  `DEFINER` varchar(77) NOT NULL default '',
  `SECURITY_TYPE` varchar(7) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `VIEWS`
--


-- --------------------------------------------------------

--
-- Table structure for table `INNODB_IO_PATTERN`
--

CREATE TEMPORARY TABLE `INNODB_IO_PATTERN` (
  `SPACE` bigint(11) NOT NULL default '0',
  `OFFSET` bigint(11) NOT NULL default '0',
  `INDEX_ID` bigint(11) NOT NULL default '0',
  `TABLE_NAME` varchar(32) NOT NULL default '',
  `INDEX_NAME` varchar(32) NOT NULL default '',
  `N_READ` bigint(11) NOT NULL default '0',
  `N_WRITE` bigint(11) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INNODB_IO_PATTERN`
--

-- in use (#1227 - Access denied; you need the PROCESS privilege for this operation)

-- --------------------------------------------------------

--
-- Table structure for table `INNODB_RSEG`
--

CREATE TEMPORARY TABLE `INNODB_RSEG` (
  `RSEG_ID` bigint(21) NOT NULL default '0',
  `SPACE_ID` bigint(21) NOT NULL default '0',
  `PAGE_NO` bigint(21) NOT NULL default '0',
  `MAX_SIZE` bigint(21) NOT NULL default '0',
  `CURR_SIZE` bigint(21) NOT NULL default '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

--
-- Dumping data for table `INNODB_RSEG`
--

-- in use (#1227 - Access denied; you need the PROCESS privilege for this operation)
